//
//  ViewController.swift
//  BakkaniGreetingApp
//
//  Created by Bakkani,Pavan Kalyan on 9/13/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    @IBOutlet weak var firstNameTF: UITextField!
    

    @IBOutlet weak var lastName: UITextField!
    
    
    @IBAction func Submit(_ sender: UIButton) {
        
        guard let funct = self.firstNameTF.text else{
            return
        }
        let Fname = funct
        guard let fun = self.lastName.text else{
            return
        }
        
        let Lname = fun
        var result = "Howdy\(Fname), \(Lname)!\n"
        
        var grade=0.0
        
        grade = Double(gpaSLDR.value)
        grade=round(grade*10)/10.0
        if(grade >= 3.0 && grade <= 4.0)
        {
            result=result+" your gpa is \(grade )good"
        }
        
        else
            if(grade >= 2.0 && grade <= 3.0)
        {
            result=result+" your gpa is \(grade) it can be improved "
        }
        else{
            result=result+" your gpa is \(grade) see your academic advisor"
            
        }
        self.greetingLBL.text=result
    }
    
    
    @IBAction func reset(_ sender: UIButton) {
        firstNameTF.text = ""
        lastName.text = ""
        gpaSLDR.value = 0.0
        greetingLBL.text = ""
    }
    
    @IBOutlet weak var gpaSLDR: UISlider!
    @IBOutlet weak var greetingLBL: UILabel!
}

