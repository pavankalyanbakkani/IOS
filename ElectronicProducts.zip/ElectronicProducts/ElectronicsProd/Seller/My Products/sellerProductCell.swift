//
//  sellerProductCell.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/04/2022.
//

import UIKit

class sellerProductCell: UICollectionViewCell {
    @IBOutlet weak var deletebutton: UIButton!
    @IBOutlet weak var pricelbl: UILabel!
    @IBOutlet weak var qtylbl: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var namelbl: UILabel!
}
