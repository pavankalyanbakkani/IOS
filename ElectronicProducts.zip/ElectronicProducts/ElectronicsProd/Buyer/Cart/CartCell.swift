//
//  CartCell.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/10/2022.
//

import UIKit

class CartCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var removebutton: UIButton!
    @IBOutlet weak var pricelbl: UILabel!
    @IBOutlet weak var quantity: UILabel!
    @IBOutlet weak var namelbl: UILabel!
    var delegate : updateCartDelegate?
    var maxQty = 0
    var productObj = Cart()
    var db_Helper = DB_Helper()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

   @IBAction func plusbtn(_ sender: Any) {
        let currentVal = Int(quantity.text ?? "0") ?? 0
        if currentVal < maxQty
        {
            let img = productObj.image ?? ""
            quantity.text = "\(currentVal + 1)"
            let isAdded = self.db_Helper.updateCartItem(buyerid: productObj.buyerid ?? 0, sellerid: productObj.sellerid ?? 0, id: productObj.id ?? 0, name: productObj.name ?? "", price: productObj.price ?? 0, warrenty: productObj.warranty ?? 0, type: productObj.type ?? "", qty: currentVal + 1, desc: productObj.desc ?? "", image: img, location: productObj.location ?? "", maxQty: maxQty, warrantyEnd: productObj.warrantyEnd ?? Date())
            if isAdded == true
            {
                UIApplication.topViewController()?.showToast(message: "Added in  cart")
            }
        }
    }
    @IBAction func minusbtn(_ sender: Any) {
        let currentVal = Int(quantity.text ?? "0") ?? 0
        if currentVal > 0
        {
            quantity.text = "\(currentVal - 1)"
            let img = productObj.image ?? ""
            let isDeleted = self.db_Helper.updateCartItem(buyerid: productObj.buyerid ?? 0, sellerid: productObj.sellerid ?? 0, id: productObj.id ?? 0, name: productObj.name ?? "", price: productObj.price ?? 0, warrenty: productObj.warranty ?? 0, type: productObj.type ?? "", qty: currentVal - 1, desc: productObj.desc ?? "", image: img, location: productObj.location ?? "", maxQty: maxQty, warrantyEnd: productObj.warrantyEnd ?? Date())
            if isDeleted == true
            {
                if (currentVal - 1) == 0
                {
                    self.delegate?.updateCart()
                }
                UIApplication.topViewController()?.showToast(message: "Removed from  cart")
            }
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
