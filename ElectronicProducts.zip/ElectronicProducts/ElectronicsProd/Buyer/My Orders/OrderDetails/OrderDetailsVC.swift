//
//  OrderDetailsVC.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 07/11/2022.
//

import UIKit

class OrderDetailsVC: UIViewController {

    @IBOutlet weak var desclbl: UILabel!
    @IBOutlet weak var orderDatelbl: UILabel!
    @IBOutlet weak var warrantyendlbl: UILabel!
    @IBOutlet weak var totallbl: UILabel!
    @IBOutlet weak var warrantylbl: UILabel!
    @IBOutlet weak var qtylbl: UILabel!
    @IBOutlet weak var pricelbl: UILabel!
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var claimVw: UIView!
    @IBOutlet weak var totalVw: UIView!
    @IBOutlet weak var dateVw: UIView!
    @IBOutlet weak var claimProductButton: UIButton!
    
  
    }

