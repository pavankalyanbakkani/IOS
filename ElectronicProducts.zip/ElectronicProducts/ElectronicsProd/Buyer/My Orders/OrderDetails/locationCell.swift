//
//  locationCell.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/11/2022.
//

import UIKit

class locationCell: UITableViewCell {

    @IBOutlet weak var txtlbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
