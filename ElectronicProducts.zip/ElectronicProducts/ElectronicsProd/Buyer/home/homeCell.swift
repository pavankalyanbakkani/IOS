//
//  homeCell.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/08/2022.
//

import UIKit

class homeCell: UICollectionViewCell {
    
    @IBOutlet weak var plusButton: UIButton!
    @IBOutlet weak var qtylbl: UILabel!
    @IBOutlet weak var minusButton: UIButton!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var pricelbl: UILabel!
    var maxQty = 0
    var productObj = Product()
    var db_Helper = DB_Helper()
    var delegate : updateCartDelegate?
 
    @IBAction func plusbtn(_ sender: Any) {
        let currentVal = Int(qtylbl.text ?? "0") ?? 0
        if currentVal < maxQty
        {
            let img = Constants.convertImageToBase64String(img: productObj.image ?? UIImage())
            qtylbl.text = "\(currentVal + 1)"
            
            let isAdded = self.db_Helper.updateCartItem(buyerid: Constants.userid, sellerid: productObj.sellerid ?? 0, id: productObj.id ?? 0, name: productObj.name ?? "", price: productObj.price ?? 0, warrenty: productObj.warranty ?? 0, type: productObj.type ?? "", qty: currentVal + 1, desc: productObj.desc ?? "", image: img, location: productObj.location ?? "", maxQty: maxQty, warrantyEnd: productObj.warrantyEnd ?? Date())
            if isAdded == true
            {
                self.delegate?.updateCart()
                UIApplication.topViewController()?.showToast(message: "Added in  cart")
            }
        }
    }
    @IBAction func minusbtn(_ sender: Any) {
        let currentVal = Int(qtylbl.text ?? "0") ?? 0
        if currentVal > 0
        {
            qtylbl.text = "\(currentVal - 1)"
            let img = Constants.convertImageToBase64String(img: productObj.image ?? UIImage())
            let isDeleted = self.db_Helper.updateCartItem(buyerid: Constants.userid, sellerid: productObj.sellerid ?? 0, id: productObj.id ?? 0, name: productObj.name ?? "", price: productObj.price ?? 0, warrenty: productObj.warranty ?? 0, type: productObj.type ?? "", qty: currentVal - 1, desc: productObj.desc ?? "", image: img, location: productObj.location ?? "", maxQty: maxQty, warrantyEnd: productObj.warrantyEnd ?? Date())
            if isDeleted == true
            {
                self.delegate?.updateCart()
                UIApplication.topViewController()?.showToast(message: "Removed from  cart")
            }
        }
    }
}
