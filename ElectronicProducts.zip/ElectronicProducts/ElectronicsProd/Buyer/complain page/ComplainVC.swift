//
//  ComplainVC.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/18/2022.
//

import UIKit

class ComplainVC: UIViewController
{
    
    @IBOutlet weak var detailstxt: UITextView!
        
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
