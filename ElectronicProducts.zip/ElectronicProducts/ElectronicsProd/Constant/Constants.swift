//
//  Constants.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/05/2022.
//

import Foundation
import UIKit

class Constants{
    
    static var ProductsList = ["iPhone", "iPad", "Cell Phone", "Refrigerator", "Oven", "Tablet", "Home Theater", "Drones", "Laptops", "Computers", "Macbooks", "Camera", "TV", "Watches", "Printers"]
    
    static var userid = 0
    static var name = ""
    static var email = ""
    static var userType = ""
    static var address = ""
    
    // Display Alert Message
    class func showAlert(_ title: String,
                         message: String,
                         actions:[UIAlertAction] = [UIAlertAction(title: "OK", style: .cancel, handler: nil)]) {
        if checkAlertExist() == false {
            
            let topView = UIApplication.topViewController()
            
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
            for action in actions {
                alert.addAction(action)
            }
            topView?.present(alert, animated: true, completion: nil)
            
            UILabel.appearance(whenContainedInInstancesOf:
                                [UIAlertController.self]).numberOfLines = 0
            UILabel.appearance(whenContainedInInstancesOf:
                                [UIAlertController.self]).lineBreakMode = .byWordWrapping
        }
    }
    
    
    class func FormattedDate(date:Date) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd - MMM - yyyy"
        let resultString = dateFormatter.string(from: date)
        return resultString
    }
    
    class func checkAlertExist() -> Bool {
        for window: UIWindow in UIApplication.shared.windows {
            if (window.rootViewController?.presentedViewController is UIAlertController) {
                return true
            }
        }
        return false
    }
    class func convertBase64StringToImage (imageBase64String:String) -> UIImage {
        let imageData = Data(base64Encoded: imageBase64String)
        let image = UIImage(data: imageData!)
        return image ?? UIImage()
        
    }
    class func convertImageToBase64String (img: UIImage) -> String {
        return img.jpegData(compressionQuality: 1)?.base64EncodedString() ?? ""
    }
}
extension UIApplication {
    
    class func topViewController(viewController: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = viewController as? UINavigationController {
            return topViewController(viewController: nav.visibleViewController)
        }
        if let tab = viewController as? UITabBarController {
            if let selected = tab.selectedViewController {
                return topViewController(viewController: selected)
            }
        }
        if let presented = viewController?.presentedViewController {
            return topViewController(viewController: presented)
        }
        
        return viewController
    }
    
}
