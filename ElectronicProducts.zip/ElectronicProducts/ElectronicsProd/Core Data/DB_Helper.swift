//
//  DB_Helper.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/03/2022.
//


import CoreData
import UIKit

class DB_Helper{
    
    var managedContext: NSManagedObjectContext? = nil
    init() {
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        managedContext = appDelegate?.persistentContainer.viewContext
    }
    
    func saveUser(email:String,name:String,address:String,password:String,userType:String) -> Bool
    {
        if (managedContext == nil) { return false}
        let entity = NSEntityDescription.entity(forEntityName: "Users", in: managedContext!)!
        let user = getUserByEmail(email: email)
        if user != nil
        {
            Constants.showAlert("Error", message: "Email already exist. Please try with another email to continue.")
            return false
        }
        else
        {
            let lastuser = getLastUserid()
            var userid = lastuser?.value(forKey: "id") as? Int ?? 0
            userid += 1
            let obj = NSManagedObject(entity: entity, insertInto: managedContext)
            obj.setValue(userid, forKeyPath: "id")
            obj.setValue(email, forKeyPath: "email")
            obj.setValue(name, forKeyPath: "name")
            obj.setValue(address, forKeyPath: "address")
            obj.setValue(password, forKeyPath: "password")
            obj.setValue(userType, forKeyPath: "userType")
            do {
                try managedContext!.save()
            }
            catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
            }
            return true
        }
    }
    
    func updateProduct(id:Int,name:String,price:Double,warrenty:Int,type:String,qty:Int,desc:String,image:String,location:String) -> Bool
    {
        if (managedContext == nil) { return false}
        
        if let product = getProductById(sellerid: Constants.userid, pId: id)
        {
            let addedDate = product.value(forKey: "dateAdded") as? Date ?? Date()
            managedContext?.delete(product)
            if qty > 0
            {
                let entity = NSEntityDescription.entity(forEntityName: "Products", in: managedContext!)!
                
                var dateComponent = DateComponents()
                dateComponent.month = warrenty
                let futureDate = Calendar.current.date(byAdding: dateComponent, to: addedDate)
                print("warranty end \(futureDate)")
                
                let obj = NSManagedObject(entity: entity, insertInto: managedContext)
                obj.setValue(NSNumber(value: Constants.userid), forKeyPath: "sellerid")
                obj.setValue(NSNumber(value: id), forKey: "id")
                obj.setValue(price, forKeyPath: "price")
                obj.setValue(name, forKeyPath: "name")
                obj.setValue(image, forKey: "image")
                obj.setValue(warrenty, forKeyPath: "warranty")
                obj.setValue(type, forKeyPath: "type")
                obj.setValue(qty, forKeyPath: "quantity")
                obj.setValue(desc, forKeyPath: "desc")
                obj.setValue(location, forKeyPath: "location")
                obj.setValue(futureDate, forKey: "warrantyEndDate")
                do {
                    try managedContext!.save()
                }
                catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
            }
            return true
        }
        else
        {
            let entity = NSEntityDescription.entity(forEntityName: "Products", in: managedContext!)!
            let lastProduct = getLastProdcutId()
            var pid = lastProduct?.value(forKey: "id") as? Int ?? 0
            pid += 1
            
            let dateTimeNow = Date()
            var dateComponent = DateComponents()
            dateComponent.month = warrenty
            let futureDate = Calendar.current.date(byAdding: dateComponent, to: dateTimeNow)
            
            let obj = NSManagedObject(entity: entity, insertInto: managedContext)
            obj.setValue(NSNumber(value: pid), forKeyPath: "id")
            obj.setValue(NSNumber(value: Constants.userid), forKeyPath: "sellerid")
            obj.setValue(dateTimeNow, forKey: "dateAdded")
            obj.setValue(price, forKeyPath: "price")
            obj.setValue(name, forKeyPath: "name")
            obj.setValue(image, forKey: "image")
            obj.setValue(warrenty, forKeyPath: "warranty")
            obj.setValue(type, forKeyPath: "type")
            obj.setValue(qty, forKeyPath: "quantity")
            obj.setValue(desc, forKeyPath: "desc")
            obj.setValue(location, forKeyPath: "location")
            obj.setValue(futureDate, forKey: "warrantyEndDate")
            do {
                try managedContext!.save()
            }
            catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
            }
            return true
        }
    }
    func updateProductByBuyer(sellerid:Int,id:Int,name:String,price:Double,warrenty:Int,type:String,qty:Int,desc:String,image:String,location:String) -> Bool
    {
        if (managedContext == nil) { return false}
        
        if let product = getProductById(sellerid: sellerid, pId: id)
        {
            managedContext?.delete(product)
            if qty > 0
            {
                let entity = NSEntityDescription.entity(forEntityName: "Products", in: managedContext!)!
                let addedDate = product.value(forKey: "dateAdded") as? Date ?? Date()
                var dateComponent = DateComponents()
                dateComponent.month = warrenty
                let futureDate = Calendar.current.date(byAdding: dateComponent, to: addedDate)
                
                let obj = NSManagedObject(entity: entity, insertInto: managedContext)
                obj.setValue(NSNumber(value: sellerid), forKeyPath: "sellerid")
                obj.setValue(NSNumber(value: id), forKey: "id")
                obj.setValue(price, forKeyPath: "price")
                obj.setValue(name, forKeyPath: "name")
                obj.setValue(image, forKey: "image")
                obj.setValue(warrenty, forKeyPath: "warranty")
                obj.setValue(type, forKeyPath: "type")
                obj.setValue(qty, forKeyPath: "quantity")
                obj.setValue(desc, forKeyPath: "desc")
                obj.setValue(location, forKeyPath: "location")
                obj.setValue(futureDate, forKey: "warrantyEndDate")
                do {
                    try managedContext!.save()
                }
                catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
            }
            return true
        }
        return true
    }
   
    func userOrder(sellerid:Int,buyerid:Int,id:Int,name:String,price:Double,warrenty:Int,type:String,qty:Int,desc:String,image:String,location:String,total:Double,warrantyEndDate:Date) -> Bool
    {
        if (managedContext == nil) { return false}

            let lastorder = getLastOrderId()
            var orderid = lastorder?.value(forKey: "ordrId") as? Int ?? 0
            orderid += 1
            
            let entity = NSEntityDescription.entity(forEntityName: "UserOrders", in: managedContext!)!
            
            let obj = NSManagedObject(entity: entity, insertInto: managedContext)
        
            obj.setValue(NSNumber(value: orderid), forKeyPath: "ordrId")
            obj.setValue(NSNumber(value: sellerid), forKeyPath: "sellerid")
            obj.setValue(NSNumber(value: buyerid), forKeyPath: "buyerid")
            obj.setValue(NSNumber(value: id), forKey: "productId")
            obj.setValue(price, forKeyPath: "price")
            obj.setValue(name, forKeyPath: "name")
            obj.setValue(image, forKey: "image")
            obj.setValue(warrenty, forKeyPath: "warranty")
            obj.setValue(type, forKeyPath: "type")
            obj.setValue(qty, forKeyPath: "quantity")
            obj.setValue(desc, forKeyPath: "desc")
            obj.setValue(location, forKeyPath: "location")
            obj.setValue(Date(), forKey: "orderDate")
            obj.setValue(total, forKey: "total")
            obj.setValue(warrantyEndDate, forKey: "warrantyEndDate")
            //obj.setValue(futureDate, forKey: "warrantyEndDate")
            do {
                try managedContext!.save()
            }
            catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
            }
            return true
        }
    func userOrderNew(buyerid:Int,total:Double,jsonData:String) -> Bool
    {
        if (managedContext == nil) { return false}

            let lastorder = getLastOrderId()
            var orderid = lastorder?.value(forKey: "ordrId") as? Int ?? 0
            orderid += 1
            
            let entity = NSEntityDescription.entity(forEntityName: "Orders", in: managedContext!)!
            
            let obj = NSManagedObject(entity: entity, insertInto: managedContext)
        
            obj.setValue(NSNumber(value: orderid), forKeyPath: "id")
            obj.setValue(NSNumber(value: buyerid), forKeyPath: "buyerId")
            obj.setValue(Date(), forKey: "orderDate")
            obj.setValue(total, forKey: "total")
            obj.setValue(jsonData, forKey: "jsonData")
            do {
                try managedContext!.save()
            }
            catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
            }
            return true
        }
    
    
    
    
    func updateCartItem(buyerid:Int,sellerid:Int,id:Int,name:String,price:Double,warrenty:Int,type:String,qty:Int,desc:String,image:String,location:String,maxQty:Int,warrantyEnd:Date) -> Bool {
        if (managedContext == nil) { return false }
        
        let entity = NSEntityDescription.entity(forEntityName: "CartData", in: managedContext!)!
        
        let cartItem = getCartProductById(buyerid: buyerid, sellerid: sellerid, pId: id)
        if (cartItem != nil) {
            
            managedContext!.delete(cartItem!)
            if (qty > 0) {
                let item = NSManagedObject(entity: entity, insertInto: managedContext)
                item.setValue(id, forKeyPath: "id")
                item.setValue(price, forKeyPath: "price")
                item.setValue(name, forKeyPath: "name")
                item.setValue(image, forKey: "image")
                item.setValue(warrenty, forKeyPath: "warranty")
                item.setValue(type, forKeyPath: "type")
                item.setValue(qty, forKeyPath: "quantity")
                item.setValue(desc, forKeyPath: "desc")
                item.setValue(location, forKeyPath: "location")
                item.setValue(maxQty, forKey: "maxQty")
                item.setValue(sellerid, forKeyPath: "sellerid")
                item.setValue(buyerid, forKeyPath: "buyerid")
                item.setValue(warrantyEnd, forKeyPath: "warrantyEndDate")
            }
        }
        else
        {
            if qty > 0
            {
                let item = NSManagedObject(entity: entity, insertInto: managedContext)
                item.setValue(id, forKeyPath: "id")
                item.setValue(price, forKeyPath: "price")
                item.setValue(name, forKeyPath: "name")
                item.setValue(image, forKey: "image")
                item.setValue(warrenty, forKeyPath: "warranty")
                item.setValue(type, forKeyPath: "type")
                item.setValue(qty, forKeyPath: "quantity")
                item.setValue(desc, forKeyPath: "desc")
                item.setValue(location, forKeyPath: "location")
                item.setValue(maxQty, forKey: "maxQty")
                item.setValue(sellerid, forKeyPath: "sellerid")
                item.setValue(buyerid, forKeyPath: "buyerid")
                item.setValue(warrantyEnd, forKeyPath: "warrantyEndDate")
            }
        }
        
        do {
            try managedContext!.save()
            return true
        }
        catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
            return false
        }
    }
    func deleteCartItem(id:Int) -> Bool
    {
        if (managedContext == nil) { return false }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartData")
        fetchRequest.predicate = NSPredicate(format: "id == %@ && buyerid == %@" , NSNumber(value: id),NSNumber(value: Constants.userid))
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        do {
            try managedContext!.execute(batchDeleteRequest)
        } catch {
            print("Could not fetch. \(error)")
        }
        
 
        return true
    }
    
    
    func getAllUsers() -> [NSManagedObject]? {
        if (managedContext == nil) { return nil }
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Users")
        do {
            let users = try managedContext!.fetch(fetchRequest)
            return users
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        return nil
    }
    func getUserAllOrdersByUserid(buyerid:Int) -> [NSManagedObject]? {
        if (managedContext == nil) { return nil }
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Orders")
        fetchRequest.predicate = NSPredicate(format: "buyerId == %@", NSNumber(value: buyerid))
        do {
            let CartList = try managedContext!.fetch(fetchRequest)
            return CartList
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    
    func getAllCartItemByUserid(buyerid:Int) -> [NSManagedObject]? {
        if (managedContext == nil) { return nil }
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "CartData")
        fetchRequest.predicate = NSPredicate(format: "buyerid == %@", NSNumber(value: buyerid))
        do {
            let CartList = try managedContext!.fetch(fetchRequest)
            return CartList
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    

    
    
    func getAllProducts() -> [NSManagedObject]? {
        if (managedContext == nil) { return nil }
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Products")
        do {
            let users = try managedContext!.fetch(fetchRequest)
            return users
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    
    func getAllProductsByUserId(sellerid:Int) -> [NSManagedObject]? {
        if (managedContext == nil) { return nil }
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Products")
        fetchRequest.predicate = NSPredicate(format: "sellerid == %@" , NSNumber(value: sellerid))
        do {
            let users = try managedContext!.fetch(fetchRequest)
            return users
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    func getAllCart() -> [NSManagedObject]? {
        if (managedContext == nil) { return nil }
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "CartData")
        //fetchRequest.predicate = NSPredicate(format: "userid == %@" , NSNumber(value: userid))
        do {
            let users = try managedContext!.fetch(fetchRequest)
            return users
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    
    func getCartProductById(buyerid:Int,sellerid:Int,pId:Int) -> NSManagedObject? {
        if (managedContext == nil) { return nil }
        do {
            let fetchRequest =  NSFetchRequest<NSManagedObject>(entityName: "CartData")
            fetchRequest.predicate = NSPredicate(format: "id == %@ && sellerid == %@ && buyerid == %@" , NSNumber(value: pId),NSNumber(value: sellerid),NSNumber(value: buyerid))
            
            let product = try managedContext?.fetch(fetchRequest)
            if product?.count ?? 0 > 0
            {
                return product?[0]
            }
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    
    func getAllCartProductById(buyerid:Int) -> [NSManagedObject]? {
        if (managedContext == nil) { return nil }
        do {
            let fetchRequest =  NSFetchRequest<NSManagedObject>(entityName: "CartData")
            fetchRequest.predicate = NSPredicate(format: "buyerid == %@" , NSNumber(value: buyerid))
            
            let products = try managedContext?.fetch(fetchRequest)
            return products
            
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    
    
    func getProductById(sellerid:Int,pId:Int) -> NSManagedObject? {
        if (managedContext == nil) { return nil }
        do {
            let fetchRequest =  NSFetchRequest<NSManagedObject>(entityName: "Products")
            fetchRequest.predicate = NSPredicate(format: "id == %@ && sellerid == %@" , NSNumber(value: pId),NSNumber(value: sellerid))
            
            let product = try managedContext?.fetch(fetchRequest)
            if product?.count ?? 0 > 0
            {
                return product?[0]
            }
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    
    
    
    func deleteAllUsers() {
        if (managedContext == nil) { return }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        do {
            try managedContext!.execute(batchDeleteRequest)
        } catch {
            print("Could not fetch. \(error)")
        }
    }
    func deleteAllorders() {
        if (managedContext == nil) { return }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "UserOrders")
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        do {
            try managedContext!.execute(batchDeleteRequest)
        } catch {
            print("Could not fetch. \(error)")
        }
    }
    func deleteOrderbyid(orderid:Int,buyerid:Int) {
        if (managedContext == nil) { return }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Orders")
        fetchRequest.predicate = NSPredicate(format: "id == %@ && buyerId == %@" , NSNumber(value: orderid),NSNumber(value: buyerid))
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        do {
            try managedContext!.execute(batchDeleteRequest)
        } catch {
            print("Could not fetch. \(error)")
        }
    }
    //UserOrders
    func deleteAllcart() {
        if (managedContext == nil) { return }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartData")
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        do {
            try managedContext!.execute(batchDeleteRequest)
        } catch {
            print("Could not fetch. \(error)")
        }
    }
    func deleteAllProducts() {
        if (managedContext == nil) { return }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Products")
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        do {
            try managedContext!.execute(batchDeleteRequest)
        } catch {
            print("Could not fetch. \(error)")
        }
    }
    func deleteProductById(sellerid:Int,productid:Int) {
        if (managedContext == nil) { return }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Products")
        fetchRequest.predicate = NSPredicate(format: "id == %@ && sellerid == %@" , NSNumber(value: productid),NSNumber(value: sellerid))
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        do {
            try managedContext!.execute(batchDeleteRequest)
        } catch {
            print("Could not fetch. \(error)")
        }
    }
    func getUserByEmail(email: String) -> NSManagedObject? {
        if (managedContext == nil) { return nil }
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.predicate = NSPredicate(format: "email == %@" , email)
        do {
            let voucherCart = try managedContext!.fetch(fetchRequest)
            
            if (voucherCart.count > 0) {
                return voucherCart[0]
            }
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        return nil
    }
    func userLogin(email: String,password:String) -> NSManagedObject? {
        if (managedContext == nil) { return nil }
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Users")
        fetchRequest.predicate = NSPredicate(format: "email == %@ && password == %@" , email,password)
        do {
            let voucherCart = try managedContext!.fetch(fetchRequest)
            
            if (voucherCart.count > 0) {
                return voucherCart[0]
            }
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    
    func getLastUserid() -> NSManagedObject?
    {
        if (managedContext == nil) { return nil }
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Users")
        do {
            let lastUser = try managedContext!.fetch(fetchRequest)
            if (lastUser.count > 0) {
                return lastUser.last
            }
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    func getLastProdcutId() -> NSManagedObject?
    {
        if (managedContext == nil) { return nil }
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Products")
        do {
            let lastProduct = try managedContext!.fetch(fetchRequest)
            if (lastProduct.count > 0) {
                return lastProduct.last
            }
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
    func getLastOrderId() -> NSManagedObject?
    {
        if (managedContext == nil) { return nil }
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "UserOrders")
        
        do {
            let lastProduct = try managedContext!.fetch(fetchRequest)
            if (lastProduct.count > 0) {
                return lastProduct.last
            }
        }
        catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return nil
    }
}
