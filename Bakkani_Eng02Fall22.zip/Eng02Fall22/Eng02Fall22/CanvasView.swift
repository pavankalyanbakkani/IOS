//
//  Canvas.swift
//  Eng02Fall22
//
//  Created by Chandra on 10/15/22.
//

import UIKit

class CanvasView: UIView {
    
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        // Getting the graphics context
        guard let context = UIGraphicsGetCurrentContext() else{
            return
        }
        
        // Orange path
        context.setFillColor(UIColor.systemOrange.cgColor)
        context.move(to: CGPoint(x: CGFloat(70), y: CGFloat(30)))
        context.addQuadCurve(to: CGPoint(x: CGFloat(150), y: CGFloat(40)), control: CGPoint(x: CGFloat(120), y: CGFloat(20)))
        context.addLine(to: CGPoint(x: CGFloat(135), y: CGFloat(100)))
        context.addQuadCurve(to: CGPoint(x: CGFloat(55), y: CGFloat(90)), control: CGPoint(x: CGFloat(100), y: CGFloat(80)))
        context.closePath()
        context.fillPath()
        
        // implement Green, Blue, and Yellow paths
        context.setFillColor(UIColor.systemBlue.cgColor)
        context.move(to: CGPoint(x: CGFloat(50), y: CGFloat(115)))
        context.addQuadCurve(to: CGPoint(x: CGFloat(130), y: CGFloat(125)), control: CGPoint(x: CGFloat(100), y: CGFloat(100)))
        context.addLine(to: CGPoint(x: CGFloat(115), y: CGFloat(185)))
        context.addQuadCurve(to: CGPoint(x: CGFloat(35), y: CGFloat(175)), control: CGPoint(x: CGFloat(80), y: CGFloat(160)))
        context.closePath()
        context.fillPath()
        
        context.setFillColor(UIColor.systemGreen.cgColor)
        context.move(to: CGPoint(x: CGFloat(170), y: CGFloat(50)))
        context.addQuadCurve(to: CGPoint(x: CGFloat(250), y: CGFloat(65)), control: CGPoint(x: CGFloat(210), y: CGFloat(75)))
        context.addLine(to: CGPoint(x: CGFloat(235), y: CGFloat(125)))
        context.addQuadCurve(to: CGPoint(x: CGFloat(155), y: CGFloat(110)), control: CGPoint(x: CGFloat(190), y: CGFloat(135)))
        context.closePath()
        context.fillPath()
        
        context.setFillColor(UIColor.systemYellow.cgColor)
        context.move(to: CGPoint(x: CGFloat(150), y: CGFloat(135)))
        context.addQuadCurve(to: CGPoint(x: CGFloat(230), y: CGFloat(150)), control: CGPoint(x: CGFloat(190), y: CGFloat(155)))
        context.addLine(to: CGPoint(x: CGFloat(215), y: CGFloat(210)))
        context.addQuadCurve(to: CGPoint(x: CGFloat(135), y: CGFloat(195)), control: CGPoint(x: CGFloat(170), y: CGFloat(215)))
        context.closePath()
        context.fillPath()
    }
}
