//
//  PosterCVC.swift
//  BakkaniEntertainmentApp
//
//  Created by Bakkani,Pavan Kalyan on 11/16/22.
//

import UIKit

class PosterCVC: UICollectionViewCell {
    
    
    
    @IBOutlet weak var moviePosterIV: UIImageView!
    
    
    

    
    
}
