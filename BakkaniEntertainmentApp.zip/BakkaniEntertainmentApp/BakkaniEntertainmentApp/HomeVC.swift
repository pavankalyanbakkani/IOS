//
//  HomeVC.swift
//  BakkaniEntertainmentApp
//
//  Created by Bakkani,Pavan Kalyan on 11/13/22.
//

import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        profileIV.layer.cornerRadius = 20
        profileIV.layer.masksToBounds = true
        profileIV.layer.borderWidth = 2
        profileIV.layer.borderColor = CGColor(red: 0, green: 103, blue: 71, alpha: 0)
        self.fullNameTF.text = "Pavan kalyan Bakkani"
        self.phoneLBL.text = "8482036688"
        self.emailLBL2.text = "pavankalyanbakkani@gmail.com"
        
        self.bioTextView.text = " Grad student at NWMSU, majoring in computer science in 3rd semester"
        
    
        
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBOutlet weak var fullNameTF: UILabel!
    
    
    
    @IBOutlet weak var emailLBL2: UILabel!
    
    
    @IBOutlet weak var phoneLBL: UILabel!
    
    
    
    @IBOutlet weak var bioTextView: UITextView!
    
    
    
    @IBOutlet weak var profileIV: UIImageView!
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
