//
//  FilmographyVC.swift
//  BakkaniEntertainmentApp
//
//  Created by Bakkani,Pavan Kalyan on 11/13/22.
//

import UIKit

class FilmographyVC: UIViewController, UICollectionViewDataSource,UICollectionViewDelegate{
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        self.moviesCV.dataSource = self
        self.moviesCV.delegate = self
       
    }
    
    
    
    
    
    
    var movies : [String] = []
    
    @IBOutlet weak var moviesCV: UICollectionView!
    
    
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        let pictureCell = collectionView.dequeueReusableCell(withReuseIdentifier: "Billboard", for: indexPath) as! PosterCVC
         
        pictureCell.moviePosterIV.image = UIImage(named: movies[indexPath.row])
        
        return pictureCell
        
        
        /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destination.
         // Pass the selected object to the new view controller.
         }
         */
        
    }
}
