//
//  Modelfile.swift
//  BakkaniEntertainmentApp
//
//  Created by Bakkani,Pavan Kalyan on 11/15/22.
//

import Foundation



struct Actor{
    var fullName: String
    var yearsActive: String
    var movies: [String]
}

struct Music{
    var title: String
    var composer: String
    var videoId: String
}

