//
//  ActorVC.swift
//  BakkaniEntertainmentApp
//
//  Created by Bakkani,Pavan Kalyan on 11/13/22.
//

import UIKit

class ActorVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.actorTableView.delegate = self
        self.actorTableView.dataSource = self
        loadgallery()
        
        // Do any additional setup after loading the view.
    }
    
    
    
        
    @IBOutlet weak var actorTableView: UITableView!
    var ActorDetails = [Actor]()
    
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ActorDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        
        let characterCell = tableView.dequeueReusableCell(withIdentifier: "performerCell", for: indexPath)
        
        characterCell.textLabel!.text = ActorDetails[indexPath.row].fullName
        characterCell.detailTextLabel!.text = ActorDetails[indexPath.row].yearsActive
        return characterCell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        artistdetails = ActorDetails[indexPath.row].movies
        self.performSegue(withIdentifier: "heroSegue", sender: indexPath)
    }
    
    
  
    
    func loadgallery()
    {
        ActorDetails.append(Actor(fullName: "Sushant Singh Rajput", yearsActive: "20", movies:[  "Kaipoche","Raabta","chichhore","Dilbechara","Shudhdesi "]))
        ActorDetails.append(Actor(fullName: "Pavan kalyan ", yearsActive: "20", movies:[  "kushi","Thammudu","badri","gabbarsingh","jalsa"]))
        
        ActorDetails.append(Actor(fullName: "Ranbir kapoor", yearsActive: "20", movies:[  "rockstar","rajneeti","Ajab_Prem_Ki_Ghazab_Kahani","Yeh-Jawaani-Hai-Deewani-Poster","Barfi!_poster"]))
        
        ActorDetails.append(Actor(fullName: "Imraan Hashmi", yearsActive: "20", movies:[  "Jannat_poster","Murder","Raaz","awarapan","zeher"]))
        
        ActorDetails.append(Actor(fullName: "Margot Robbie", yearsActive: "20", movies:[  "Thewolfofwallstreet","focus","SuicideSquad","amsterdam","dreamland"]))
        
        
        
    }
    
   
    var artistdetails: [String] = []
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let identifier = segue.identifier{
            switch identifier{
            case "heroSegue":
                if let filmVC = segue.destination as? FilmographyVC{
                    filmVC.movies = self.artistdetails
                }
            default:
                return
            }
        }
    }
    
       
    
   
    
    
    
}
