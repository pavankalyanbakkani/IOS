//
//  ModelFile.swift
//  BakkaniBearcatAutoApp
//
//  Created by Bakkani,Pavan Kalyan on 29/11/22.
//

import Foundation

struct ModelCar{
    var id: String{
        "S\(Int.random(in: 000009...99999))"
    }
    var make: String
    var model: String
    var year: Int16
    var price: Double
}

struct ModelTransaction{
    var customerName: String
    var date: Date
    var id: String{
        "S\(Int.random(in: 000009...99999))"
    }
    
}
