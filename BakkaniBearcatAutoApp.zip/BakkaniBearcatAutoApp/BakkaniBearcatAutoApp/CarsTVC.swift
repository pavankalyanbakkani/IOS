//
//  CarsTVC.swift
//  BakkaniBearcatAutoApp
//
//  Created by Bakkani,Pavan Kalyan on 11/22/22.
//

import UIKit
import CoreData

class CarsTVC: FetchedResultsTVC {
    var fetchedResultsController: NSFetchedResultsController<Car>?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Cars"
        self.getCars()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    
    
    
    @IBAction func createCar(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "Altima", sender: sender)
    }
    
    private func getCars(){
        let request: NSFetchRequest<Car> = Car.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(key: "make", ascending: true)]
        fetchedResultsController = NSFetchedResultsController(fetchRequest: request, managedObjectContext: AppDelegate.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController?.delegate = self
        try? fetchedResultsController?.performFetch()
        self.tableView.reloadData()
        
    }
        
        // MARK: - Table view data source
        
        override func numberOfSections(in tableView: UITableView) -> Int {
            // #warning Incomplete implementation, return the number of sections
            fetchedResultsController?.sections?.count ?? 0
        }
        
        override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            // #warning Incomplete implementation, return the number of rows
            fetchedResultsController?.sections?[section].numberOfObjects ?? 0
        }
        
        
         override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "nissan", for: indexPath)
             let car = fetchedResultsController?.object(at: indexPath)
             cell.textLabel?.text = String(format: "%@    %@    %@",car!.make!,car!.model!,String(car!.year))
                         cell.detailTextLabel?.text = "$\(String(car!.price))"
         // Configure the cell...
         
         return cell
         }
         
        
        /*
         // Override to support conditional editing of the table view.
         override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
         // Return false if you do not want the specified item to be editable.
         return true
         }
         */
        
        /*
         // Override to support editing the table view.
         override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
         if editingStyle == .delete {
         // Delete the row from the data source
         tableView.deleteRows(at: [indexPath], with: .fade)
         } else if editingStyle == .insert {
         // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
         }
         }
         */
        
        /*
         // Override to support rearranging the table view.
         override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
         
         }
         */
        
        /*
         // Override to support conditional rearranging of the table view.
         override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
         // Return false if you do not want the item to be re-orderable.
         return true
         }
         */
        
        /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destination.
         // Pass the selected object to the new view controller.
         }
         */
        
    }

