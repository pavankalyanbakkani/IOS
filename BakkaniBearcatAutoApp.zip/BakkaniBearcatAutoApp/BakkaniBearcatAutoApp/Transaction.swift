//
//  Transaction.swift
//  BakkaniBearcatAutoApp
//
//  Created by Bakkani,Pavan Kalyan on 29/11/22.
//

import UIKit
import CoreData

class Transaction: NSManagedObject {
    static func createTransaction(with id: String, timestamp: Date, custName: String, for car: Car, in context: NSManagedObjectContext) throws{
        
    }

}
