//
//  Car.swift
//  BakkaniBearcatAutoApp
//
//  Created by Bakkani,Pavan Kalyan on 29/11/22.
//

import UIKit
import CoreData

class Car: NSManagedObject {
    static func create(_ car: ModelCar, with id: String?, in context: NSManagedObjectContext) throws{
        func addToTransactions(_ value: Transaction) throws{
            
        }
        let request: NSFetchRequest<Car> = Car.fetchRequest()
        request.predicate = NSPredicate(format: "any id == %@", car.id)
        do{
            let matches = try context.fetch(request)
            if matches.count == 0{
                let carC = Car(context: context)
                carC.make = car.make
                carC.model = car.model
                carC.year = car.year
                carC.price = car.price
                carC.transactions = NSSet()
                try context.save()
            }
        }catch{
            throw error
        }
    }
}
