//
//  ViewController.swift
//  BakkaniBearcatAutoApp
//
//  Created by Bakkani,Pavan Kalyan on 11/19/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

