//
//  Create CarVC.swift
//  BakkaniBearcatAutoApp
//
//  Created by Bakkani,Pavan Kalyan on 11/22/22.
//

import UIKit

class Create_CarVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    @IBOutlet weak var carMakeTF: UITextField!
    
    
    @IBOutlet weak var carModelTF: UITextField!
    
    
    @IBOutlet weak var carYearTF: UITextField!
    
    
    @IBOutlet weak var carPriceTF: UITextField!
    
    @IBAction func submit(_ sender: UIButton) {
        guard let make = self.carMakeTF.text else {return}
        guard let model = self.carModelTF.text else {return}
        guard let year = self.carYearTF.text else {return}
        guard let price = self.carPriceTF.text else {return}
        
        if !make.isEmpty && !model.isEmpty && !year.isEmpty && !price.isEmpty{
            let car = ModelCar(make: make, model: model, year: Int16(year)!, price: Double(price)!)
            try? Car.create(car, with: "id", in: AppDelegate.viewContext)
            
            let alert = UIAlertController(title: "Success ✅", message: "Added a new car", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: {[weak self] _ in
                self?.dismiss(animated: true)
            }))
            self.present(alert, animated: true)
        }
    }
    
    
    @IBAction func cancel(_ sender: UIButton) {
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
