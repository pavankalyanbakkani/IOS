//
//  ViewController.swift
//  ElectronicsProd
//
//  Created by Student on 03/11/2022.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    var dbHelper = DB_Helper()
    var id = 2
    override func viewDidLoad() {
        super.viewDidLoad()

  
    }
    @IBAction func addbtn(_ sender: Any) {
        self.saveUser()
    }
    @IBAction func getallbtn(_ sender: Any) {
        self.getAlluser()
    }
    func saveUser()
    {
        if id % 2 == 0
        {
            //self.dbHelper.saveUser(email: "test email \(id)", name: "test name \(id)", address: "test address \(id)", password: "123456", userType: "buyer")
            id += 1
        }
        else
        {
            //self.dbHelper.saveUser(email: "test email \(id)", name: "test name \(id)", address: "test address \(id)", password: "123456", userType: "seller")
            id += 1
        }
        
    }
    
    func getAlluser()
    {
        self.dbHelper.getAllUsers()?.forEach({ (obj) in
            let id = obj.value(forKey: "id") as? Int ?? 0
            let name = obj.value(forKey: "name") as? String ?? ""
            let email = obj.value(forKey: "email") as? String ?? ""
            let userType = obj.value(forKey: "userType") as? String ?? ""
            let pass = obj.value(forKey: "password") as? String ?? ""
            let address = obj.value(forKey: "address") as? String ?? ""

            print("userid \(id),\n name \(name),\n email \(email), \n userType \(userType), \n password \(pass), \n address \(address)")
        })
    }
}

