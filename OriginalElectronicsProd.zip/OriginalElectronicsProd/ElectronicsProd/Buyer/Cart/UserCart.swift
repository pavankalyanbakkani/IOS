//
//  UserCart.swift
//  ElectronicsProd
//
//  Created by Student on 05/11/2022.
//

import UIKit

class UserCart: UIViewController,UITableViewDelegate,UITableViewDataSource,updateCartDelegate {
    
    
    @IBOutlet weak var buyButton: UIButton!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var cartTbl: UITableView!
    var db_Helper = DB_Helper()
    var cartList = [Cart]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Cart"
        cartTbl.delegate = self
        cartTbl.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.getCartData()
    }
    func getCartData()
    {
        cartList.removeAll()
        self.db_Helper.getAllCartItemByUserid(buyerid: Constants.userid)?.forEach({(obj) in
            
            let name = obj.value(forKey: "name") as? String ?? ""
            let qty = obj.value(forKey: "quantity") as? Int ?? 0
            let price = obj.value(forKey: "price") as? Double ?? 0
            let warrenty = obj.value(forKey: "warranty") as? Int ?? 0
            let id = obj.value(forKey: "id") as? Int ?? 0
            let type = obj.value(forKey: "type") as? String ?? ""
            let location = obj.value(forKey: "location") as? String ?? ""
            let maxQty = obj.value(forKey: "maxQty") as? Int ?? 0
            let buyerid = obj.value(forKey: "buyerid") as? Int ?? 0
            let sellerid = obj.value(forKey: "sellerid") as? Int ?? 0
            let warrantyEndDate = obj.value(forKey: "warrantyEndDate") as? Date ?? Date()
            let image = obj.value(forKey: "image") as? String ?? ""
            let desc = obj.value(forKey: "desc") as? String ?? ""
            self.cartList.append(Cart(name: name, qty: 0, price: price, warranty: warrenty, id: id, type: type, location: location, image: image, desc: desc, cartValue: qty,maxQuantity: maxQty,sellerid: sellerid, buyerid: buyerid,warrantyEnd: warrantyEndDate))
        })
        self.cartTbl.reloadData()
        if cartList.count > 0
        {
            self.clearButton.isHidden = false
            self.buyButton.isHidden = false
        }
        else
        {
            self.clearButton.isHidden = true
            self.buyButton.isHidden = true
            Constants.showAlert("", message: "No Products added yet")
            return
        }
    }
    func updateCart() {
        getCartData()
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "payment"
        {
            let vc = segue.destination as! PaymentVC
            vc.cartList = self.cartList
            vc.title = "Payment"
        }
    }
    @IBAction func buybtn(_ sender: Any) {
        self.performSegue(withIdentifier: "payment", sender: nil)
    }
    @IBAction func clearCartbtn(_ sender: Any) {
        self.alert(title: "Confirmation", message: "Are you sure you want to clear your cart?", productId: 0, isDeleteAll: true)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        cartList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CartCell") as! CartCell
        cell.productObj = cartList[indexPath.row]
        cell.img.image = Constants.convertBase64StringToImage(imageBase64String: cartList[indexPath.row].image ?? "")
        cell.namelbl.text = cartList[indexPath.row].name ?? ""
        cell.quantity.text = "\(cartList[indexPath.row].cartValue ?? 0)"
        cell.pricelbl.text = "\(cartList[indexPath.row].price ?? 0)"
        cell.pricelbl.text = "\(cartList[indexPath.row].price ?? 0)"
        cell.delegate = self
        cell.maxQty = cartList[indexPath.row].maxQuantity ?? 0
        cell.removebutton.tag = indexPath.row
        cell.removebutton.addTarget(self, action: #selector(removeClicked(sender:)), for: .touchUpInside)
        return cell
    }
    @objc func removeClicked(sender:UIButton){
        
       if let id = self.cartList[sender.tag].id
        {
           self.alert(title: "Confirmation", message: "Are you sure you want to remove this item from cart?", productId: id, isDeleteAll: false)
       }
    }
    
    func alert(title:String,message:String,productId : Int,isDeleteAll:Bool)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let cancel = UIAlertAction(title: "No", style: .default, handler: { action in
        })
        alert.addAction(cancel)
        let ok = UIAlertAction(title: "Yes", style: .default, handler: { action in
            if isDeleteAll == false
            {
                let isdeleted = self.db_Helper.deleteCartItem(id: productId)
                if isdeleted == true
                {
                    self.showToast(message: "Item successfully removed from cart.")
                    self.getCartData()
                }
            }
            else
            {
                self.db_Helper.deleteAllcart()
                self.showToast(message: "Cart cleared successfully.")
                self.getCartData()
                self.tabBarController?.selectedIndex = 0
            }
        })
        alert.addAction(ok)
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true)
        })
    }
}
