//
//  HomeVc.swift
//  ElectronicsProd
//
//  Created by Student on 04/11/2022.
//

import UIKit

class HomeVc: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout ,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource,filterDelegates{
    
    @IBOutlet weak var locationTxt: UITextField!
    @IBOutlet weak var searchtxt: UITextField!
    @IBOutlet weak var filterVw: UIView!
    @IBOutlet weak var productColl: UICollectionView!
    var products = [Product]()
    var cartItems = [Cart]()
    var dbHelper = DB_Helper()
    var ProductsCopy = [Product]()
    var minPrice = 0
    var maxPrice = 100000
    var filterTypes = [String]()
    var selectedProduct = Product()
    
    let locations = ["California",
                     "New York",
                     "New Jersey",
                     "Texas",
                     "Florida",
                     "Georgia"]
    let locationPicker = UIPickerView()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Products"
        locationPicker.delegate = self
        productColl.delegate = self
        productColl.dataSource = self
        self.locationTxt.delegate = self
        self.searchtxt.delegate = self
        self.locationTxt.inputView = locationPicker
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.filterTap(_:)))
        self.filterVw.addGestureRecognizer(tap)
        self.filterVw.isHidden = true
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "filter"
        {
            self.products = self.ProductsCopy
            let vc = segue.destination as! FilterVC
            vc.delegate = self
        }
        else if segue.identifier == "detail"
        {
            let vc = segue.destination as! OrderDetailsVC
            vc.isClaim = false
            vc.selectedProduct = self.selectedProduct
        }
    }
    @objc func filterTap(_ sender: UITapGestureRecognizer? = nil) {
        self.locationTxt.text = ""
        self.locationTxt.resignFirstResponder()
        self.searchtxt.resignFirstResponder()
        self.searchtxt.text = ""
        self.products = self.ProductsCopy
        
        self.performSegue(withIdentifier: "filter", sender: nil)
    }
    override func viewWillAppear(_ animated: Bool) {
        self.searchtxt.text = ""
        self.locationTxt.text = ""
        self.getAllProducts()
    }
    func getAllProducts()
    {
        self.products.removeAll()
        self.cartItems.removeAll()
        dbHelper.getAllProducts()?.forEach({ (obj) in
            let id = obj.value(forKey: "id") as? Int ?? 0
            let sellerid = obj.value(forKey: "sellerid") as? Int ?? 0
            let warranty = obj.value(forKey: "warranty") as? Int ?? 0
            let type = obj.value(forKey: "type") as? String ?? ""
            let name = obj.value(forKey: "name") as? String ?? ""
            let quantity = obj.value(forKey: "quantity") as? Int ?? 0
            let price = obj.value(forKey: "price") as? Double ?? 0
            let location = obj.value(forKey: "location") as? String ?? ""
            let desc = obj.value(forKey: "desc") as? String ?? ""
            let img = obj.value(forKey: "image") as? String ?? ""
            let warrantyEnd = obj.value(forKey: "warrantyEndDate") as? Date ?? Date()
            let uiimg = Constants.convertBase64StringToImage(imageBase64String: img)
            self.products.append(Product(name: name, qty: quantity, price: price, warranty: warranty, id: id, type: type, location: location, image: uiimg,desc: desc,cartValue: 0, sellerid: sellerid,warrantyEnd: warrantyEnd))
        })
        self.productColl.reloadData()
        if self.products.count < 1
        {
            self.filterVw.isHidden = true
            self.locationTxt.isEnabled = false
            self.searchtxt.isEnabled = false
            Constants.showAlert("", message: "No Products added yet")
            return
        }
        else
        {
            self.filterVw.isHidden = false
            self.locationTxt.isEnabled = true
            self.searchtxt.isEnabled = true
        }
        self.getCartItems()
    }
    func getCartItems()
    {
        self.dbHelper.getAllCartItemByUserid(buyerid: Constants.userid)?.forEach({ (obj) in
            let id = obj.value(forKey: "id") as? Int ?? 0
            let sellerid = obj.value(forKey: "sellerid") as? Int ?? 0
            let buyerid = obj.value(forKey: "buyerid") as? Int ?? 0
            let warranty = obj.value(forKey: "warranty") as? Int ?? 0
            let type = obj.value(forKey: "type") as? String ?? ""
            let name = obj.value(forKey: "name") as? String ?? ""
            let quantity = obj.value(forKey: "quantity") as? Int ?? 0
            let price = obj.value(forKey: "price") as? Double ?? 0
            let location = obj.value(forKey: "location") as? String ?? ""
            let desc = obj.value(forKey: "desc") as? String ?? ""
            let img = obj.value(forKey: "image") as? String ?? ""
            let warrantyEndDate = obj.value(forKey: "warrantyEndDate") as? Date ?? Date()
            //let uiimg = Constants.convertBase64StringToImage(imageBase64String: img)
            self.cartItems.append(Cart(name: name, qty: 0, price: price, warranty: warranty, id: id, type: type, location: location, image: img, desc: desc, cartValue: quantity, sellerid: sellerid, buyerid: buyerid,warrantyEnd: warrantyEndDate))
        })
        
        for i in 0..<products.count
        {
            let item = cartItems.first{$0.id == products[i].id}
            if item != nil
            {
                products[i].cartValue = item?.cartValue
            }
        }
        self.productColl.reloadData()
        self.ProductsCopy = self.products
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == searchtxt
        {
            if textField.text?.count ?? 0 > 1
            {
                self.products = self.products.filter({(($0.name ?? "").localizedCaseInsensitiveContains(textField.text ?? ""))})
                self.productColl.reloadData()
            }
            else
            {
                self.products = self.ProductsCopy
                self.productColl.reloadData()
            }
        }
        return true
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        locations.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return locations[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        locationTxt.text = locations[row]
        self.updateList(name: locations[row])
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == locationTxt
        {
            locationTxt.text = locations[0]
            self.updateList(name: locations[0])
        }
        return true
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "homeCell", for: indexPath) as! homeCell
        cell.qtylbl.text = "\(products[indexPath.row].cartValue ?? 0)"
        cell.maxQty = products[indexPath.row].qty ?? 0
        cell.namelbl.text = products[indexPath.row].name ?? ""
        cell.img.image = products[indexPath.row].image ?? UIImage()
        cell.pricelbl.text = "\(products[indexPath.row].price ?? 0)"
        cell.productObj = products[indexPath.row]
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.selectedProduct = self.products[indexPath.row]
        self.performSegue(withIdentifier: "detail", sender: nil)
    }


        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let size = UIScreen.main.bounds
            return CGSize(width: size.width / 2 - 10, height: size.width / 2)
        }

   
    
    func updateList(name:String)
    {
        
        self.products = self.ProductsCopy
        var filteredArray = [Product]()
        for product in products {
            if self.products.contains(where: {$0.location == name})
            {
                filteredArray.append(product)
            }
        }
        self.products = filteredArray
        self.productColl.reloadData()
    }
    
    
    
    func getFilterValue(isApplied: Bool, types: [String], min: Int, max: Int, locations: [String]) {
        if isApplied == true
        {
            var filteredData = [Product]()
             for product in products
            {
                 if max > 0
                 {
                     if locations.contains(where: {$0 == product.location}) && types.contains(where: {$0 == product.type}) && product.price ?? 0 >= Double(min) && product.price ?? 0 <= Double(max)
                     {
                         filteredData.append(product)
                     }
                 }
                 else
                 {
                     if locations.contains(where: {$0 == product.location}) && types.contains(where: {$0 == product.type}) && product.price ?? 0 >= Double(min)
                     {
                         filteredData.append(product)
                     }
                 }
             }
                self.products = filteredData
                productColl.reloadData()
        }
        else
        {
            self.products = ProductsCopy
            productColl.reloadData()
        }
    }
}

protocol updateCartDelegate {
    func updateCart()
}
