//
//  OrderDetailsVC.swift
//  ElectronicsProd
//
//  Created by Student on 07/11/2022.
//

import UIKit

class OrderDetailsVC: UIViewController {

    @IBOutlet weak var desclbl: UILabel!
    @IBOutlet weak var orderDatelbl: UILabel!
    @IBOutlet weak var warrantyendlbl: UILabel!
    @IBOutlet weak var totallbl: UILabel!
    @IBOutlet weak var warrantylbl: UILabel!
    @IBOutlet weak var qtylbl: UILabel!
    @IBOutlet weak var pricelbl: UILabel!
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var claimVw: UIView!
    @IBOutlet weak var totalVw: UIView!
    @IBOutlet weak var dateVw: UIView!
    @IBOutlet weak var claimProductButton: UIButton!
    
    var isClaim = true
    var selectedProduct = Product()
    var selectedOrder = Cart()
    var dbhelper = DB_Helper()
    var orderDate = Date()
    var orderid = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Order Details"
        if self.isClaim == false
        {
            self.claimVw.isHidden = true
            self.totalVw.isHidden = true
            self.dateVw.isHidden = true
            setupProductVw()
        }
        else
        {
            setupOrderVw()
        }
        getprodetails()
    }

    func setupOrderVw()
    {
        img.image = Constants.convertBase64StringToImage(imageBase64String: selectedOrder.image ?? "")
        namelbl.text = selectedOrder.name ?? ""
        pricelbl.text = "\(selectedOrder.price ?? 0)"
        qtylbl.text = "\(selectedOrder.cartValue ?? 0)"
        if selectedOrder.warranty ?? 0 <= 1
        {
            self.warrantylbl.text = "\(selectedOrder.warranty ?? 0) month"
        }
        else
        {
            self.warrantylbl.text = "\(selectedOrder.warranty ?? 0) months"
        }
        self.totallbl.text = "\(selectedOrder.price ?? 0)"
        self.desclbl.text = selectedOrder.desc ?? ""

        let srtDate = Constants.FormattedDate(date: self.orderDate)
        orderDatelbl.text = srtDate
        
        let warrantyend = Constants.FormattedDate(date: selectedOrder.warrantyEnd ?? Date())
        warrantyendlbl.text = warrantyend

    }
    func setupProductVw()
    {
        img.image = selectedProduct.image ?? UIImage()
        namelbl.text = selectedProduct.name ?? ""
        pricelbl.text = "\(selectedProduct.price ?? 0)"
        qtylbl.text = "\(selectedProduct.cartValue ?? 0)"
        if selectedProduct.warranty ?? 0 <= 1
        {
            self.warrantylbl.text = "\(selectedProduct.warranty ?? 0) month"
        }
        else
        {
            self.warrantylbl.text = "\(selectedProduct.warranty ?? 0) months"
        }
        self.desclbl.text = selectedProduct.desc ?? ""
        let warrantyend = Constants.FormattedDate(date: selectedProduct.warrantyEnd ?? Date())
        warrantyendlbl.text = warrantyend
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "complain"
        {
            let vc = segue.destination as! ComplainVC
            vc.selectedOrder = self.selectedOrder
            vc.orderid = self.orderid
        }
    }
    @IBAction func complainbtn(_ sender: Any) {
        self.performSegue(withIdentifier: "complain", sender: nil)
    }
    func getprodetails()
    {
        if self.dbhelper.getcomplainItem(buyerid: self.selectedOrder.buyerid ?? 0, productId: self.selectedOrder.id ?? 0, sellerid: self.selectedOrder.sellerid ?? 0, orderid: self.orderid) != nil
      {
            self.claimProductButton.setTitle("Already Claimed", for: .normal)
            self.claimProductButton.isEnabled = false
      }
    }
}
