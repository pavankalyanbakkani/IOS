//
//  SellerProductsVC.swift
//  ElectronicsProd
//
//  Created by Student on 04/11/2022.
//

import UIKit

class SellerProductsVC: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{

    var dbHelper = DB_Helper()
    var products = [Product]()
    var selectedProduct = Product()
    var isAdding = false
    var isEdit = false
    
    
    @IBOutlet weak var productColl: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "My Products"
        productColl.delegate = self
        productColl.dataSource = self
    }
    override func viewWillAppear(_ animated: Bool) {
        selectedProduct = Product()
        isEdit = false
        isAdding = false
        getUserProducts()
    }
    @IBAction func logoutbtn(_ sender: Any) {
        self.alert()
    }
    @IBAction func addProductBtn(_ sender: Any) {
        isAdding = true
        self.performSegue(withIdentifier: "productDetails", sender: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "productDetails"
        {
            let vc = segue.destination as! SellerProductDetailVC
            vc.selectedProduct = self.selectedProduct
            vc.isEdit = self.isEdit
            vc.isAdding = self.isAdding
        }
    }
    func getUserProducts()
    {
        self.products.removeAll()
        dbHelper.getAllProductsByUserId(sellerid: Constants.userid)?.forEach({ (obj) in
            let id = obj.value(forKey: "id") as? Int ?? 0
            let warranty = obj.value(forKey: "warranty") as? Int ?? 0
            let type = obj.value(forKey: "type") as? String ?? ""
            let name = obj.value(forKey: "name") as? String ?? ""
            let quantity = obj.value(forKey: "quantity") as? Int ?? 0
            let price = obj.value(forKey: "price") as? Double ?? 0
            let location = obj.value(forKey: "location") as? String ?? ""
            let desc = obj.value(forKey: "desc") as? String ?? ""
            let img = obj.value(forKey: "image") as? String ?? ""
            let uiimg = Constants.convertBase64StringToImage(imageBase64String: img)
            self.products.append(Product(name: name, qty: quantity, price: price, warranty: warranty, id: id, type: type, location: location, image: uiimg,desc: desc,sellerid: Constants.userid))
        })
        print("products \(self.products)")
        self.productColl.reloadData()
        if products.count < 1
        {
            Constants.showAlert("", message: "No Products added yet")
            return
        }
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "sellerProductCell", for: indexPath) as! sellerProductCell
        cell.qtylbl.text = "\(products[indexPath.row].qty ?? 0)"
        cell.img.image = products[indexPath.row].image ?? UIImage()
        cell.namelbl.text = products[indexPath.row].name ?? ""
        cell.pricelbl.text = "\(products[indexPath.row].price ?? 0)"
        cell.deletebutton.tag = indexPath.row
        cell.deletebutton.addTarget(self, action: #selector(deleteClicked(sender:)), for: .touchUpInside)
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.selectedProduct = self.products[indexPath.row]
        self.isAdding = false
        self.isEdit = false
        self.performSegue(withIdentifier: "productDetails", sender: nil)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
            return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        }

        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let size = UIScreen.main.bounds
            return CGSize(width: size.width / 2 - 15, height: (size.width / 2) + 50)
        }

        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
            return 0.0
        }

        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
            return 0.0
        }
    
    
    func alert()
    {
        let refreshAlert = UIAlertController(title: "Logout", message: "Are you sure you want to logoout?", preferredStyle: UIAlertController.Style.alert)

        refreshAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action: UIAlertAction!) in
              print("Handle Cancel Logic here")
        }))
        refreshAlert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action: UIAlertAction!) in
              print("Handle Ok logic here")
            
            UserDefaults.standard.set(false, forKey: "isLoggedIn")
            UserDefaults.standard.set(0, forKey: "userid")
            UserDefaults.standard.set("", forKey: "name")
            UserDefaults.standard.set("", forKey: "email")
            UserDefaults.standard.set("", forKey: "userType")
            
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController") as! UINavigationController
            UIApplication.shared.keyWindow?.rootViewController = viewController;
            return
        }))

        present(refreshAlert, animated: true, completion: nil)
    }
    
    
    @objc func deleteClicked(sender:UIButton){
        
        if let productid = self.products[sender.tag].id
        {
            self.deleteAlert(productid: productid)
        }
    }
    func deleteAlert(productid:Int)
    {
        let refreshAlert = UIAlertController(title: "Confirmation", message: "Are you sure you want to delete this product?", preferredStyle: UIAlertController.Style.alert)

        refreshAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action: UIAlertAction!) in
              print("Handle Cancel Logic here")
        }))
        refreshAlert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action: UIAlertAction!) in
              print("Handle Ok logic here")
            self.deleteProductId(productId: productid)
            return
        }))

        present(refreshAlert, animated: true, completion: nil)
    }
    func deleteProductId(productId:Int)
    {
        self.dbHelper.deleteProductById(sellerid: Constants.userid, productid: productId)
        self.getUserProducts()
    }
}
