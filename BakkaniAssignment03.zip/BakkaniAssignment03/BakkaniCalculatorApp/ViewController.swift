//
//  ViewController.swift
//  BakkaniCalculatorApp
//
//  Created by Bakkani,Pavan Kalyan on 9/19/22.
//

import UIKit
import MathExpression

class ViewController: UIViewController {

    override func viewDidLoad()
  {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
  }


    @IBOutlet weak var mathExpressionLBL: UILabel!
    
    
    @IBAction func clearExpression(_ sender: Any)
    {
        self.mathExpressionLBL.text = "0"
    }
    @IBAction func backspace(_ sender: Any)
    {
        let xyz = mathExpressionLBL.text!.dropLast()
        self.mathExpressionLBL.text! = String(xyz)
    }
    
    
    @IBAction func flipSign(_ sender: Any)
    {
        let val1 = self.evaluate(exp: self.mathExpressionLBL.text!+"*(-1)")
                
                self.mathExpressionLBL.text! = String(val1)
    }
    
    @IBAction func percent(_ sender: Any)
    {
        let val2 = self.evaluate(exp: self.mathExpressionLBL.text!+"*(0.01)")
                
                self.mathExpressionLBL.text! = String(val2)
    }
    
    
    @IBAction func naturalLog(_ sender: Any)
    {
        let val3 = self.evaluate(exp: self.mathExpressionLBL.text!)
        let res1 = Double(val3)
        self.mathExpressionLBL.text! = String(log(res1))

    }
    
    
    
    @IBAction func eulersNumber(_ sender: Any)
    {
        let val4 = self.evaluate(exp: self.mathExpressionLBL.text!)
    
                
                let res2 = Double(val4)
                
                self.mathExpressionLBL.text! = String(exp(res2))
    }
    
    @IBAction func squareRootOf(_ sender: Any)
    {
        let val5 = self.evaluate(exp: self.mathExpressionLBL.text!)
               
        let res3 = Double(val5)
               
        self.mathExpressionLBL.text! = String(pow(res3,0.5))

    }
    
    @IBAction func tappedChar(_ sender: UIButton)
    {
        guard let bnT = sender.titleLabel?.text else
    {
                            
        return
    }
                
    if bnT == "-" || bnT == "+" {
                            
    let val6 = self.evaluate(exp: self.mathExpressionLBL.text!)
                            
    self.mathExpressionLBL.text = isInteger(value: val6) ? "\(Int(val6))" : "\(val6)"
                            
    self.mathExpressionLBL.text! += bnT == "-" ? "-" : "+"
                            
    }
        else if
            
            bnT == "×" || bnT == "÷"
        {
                                
            let val7 = self.evaluate(exp: self.mathExpressionLBL.text!)
                                
            self.mathExpressionLBL.text = isInteger(value: val7) ? "\(Int(val7))" : "\(val7)"
                                
            self.mathExpressionLBL.text! += bnT == "÷" ? "/" : "*"
                                
        }
                
        else{
                            
            self.mathExpressionLBL.text! += bnT
            }

       }
    
    
    
    @IBAction func result(_ sender: Any)
    {
        let output = self.evaluate(exp: self.mathExpressionLBL.text!)
                            
        self.mathExpressionLBL.text = isInteger(value: output) ? "\(Int(output))" : "\(output)"
                            

        
    }
    private func evaluate(exp: String) -> Double
    {
                
        do{
            var expression = try MathExpression(exp)
                        
            return expression.evaluate()
          }
        catch
        {
            
            print("Invalid expression")
        }
                
                return 0.0
    }
    
    
        
    
    private func isInteger(value: Double) -> Bool
    {
                
        value.truncatingRemainder(dividingBy: 1.0).isZero

    }
    }
