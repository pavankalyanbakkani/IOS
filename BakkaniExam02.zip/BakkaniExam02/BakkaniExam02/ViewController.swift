//
//  ViewController.swift
//  BakkaniExam02
//
//  Created by Bakkani,Pavan Kalyan on 11/15/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

