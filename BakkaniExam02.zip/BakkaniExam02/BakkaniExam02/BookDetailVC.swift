//
//  BookDetailVC.swift
//  BakkaniExam02
//
//  Created by Bakkani,Pavan Kalyan on 11/15/22.
//

import UIKit

class BookDetailVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBOutlet weak var BookIV: UIImageView!
    
    
    
    @IBOutlet weak var bookTitleLBL: UILabel!
    
    
    @IBOutlet weak var bookPriceLBL: UILabel!
    
    
    
    @IBOutlet weak var bookDiscountLBL: UILabel!
    
    @IBOutlet weak var totalCostOfBookLBL: UILabel!
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
