//
//  ViewController.swift
//  BookAFlight
//
//  Created by Bakkani,Pavan Kalyan on 9/27/22.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var displayLBL: UILabel!
    
    @IBOutlet weak var oneWayBTN: UIButton!
    
    @IBAction func oneWay(_ sender: UIButton) {
        self.twoWayBTN.isEnabled=false
                self.arrivalDateTF.isEnabled=false
    }
    @IBOutlet weak var twoWayBTN: UIButton!
    
    @IBAction func twoWay(_ sender: UIButton) {
        self.oneWayBTN.isEnabled=false
                self.arrivalDateTF.isEnabled=true
    }
    
    @IBAction func submit(_ sender: UIButton) {
        let NOOFPAssengers = (self.noOfPassTF.text)
                let NOOFPAssengers2 = Int(NOOFPAssengers!)
                var Amount: Int = 0
                
                switch NOOFPAssengers2! {
                case (1...3):
                    Amount = 1000
                case(4...6):
                    Amount = 500
                case (7...):
                    Amount = 300
                default:
                    Amount = 0
                }
                
        
        let TripCost = Amount*NOOFPAssengers2!
                
                if(self.oneWayBTN.isEnabled){
                
                    self.displayLBL.text = "Congratulations  \( self.fullNameTF.text!)!\n your travel from \(self.sourceTF.text!) to \(self.destinationTF.text!) is confirmed! on \(self.departureDateTF.text!) \n Your total cost is: $\(TripCost)"
                    
                }
                
                if (self.twoWayBTN.isEnabled){
                    self.displayLBL.text = "Congratulations \(self.fullNameTF.text!)! \n your travel from \(self.sourceTF.text!) to \(self.destinationTF.text!) is confirmed on \(self.departureDateTF.text!) and arrival from   \(self.destinationTF.text!) to \(self.sourceTF.text!) is confirmed on \(self.arrivalDateTF.text!) \n Your total cost is: $\(TripCost*2)"
                    
                }

    }
    
    
    @IBAction func reset(_ sender: Any) {
        self.oneWayBTN.isEnabled=true
                self.twoWayBTN.isEnabled=true
                
                self.fullNameTF.text=""
                self.sourceTF.text=""
                self.destinationTF.text=""
                self.arrivalDateTF.text=""
                self.noOfPassTF.text=""
        self.departureDateTF.text=""
                self.displayLBL.text=""
    }
    
    @IBOutlet weak var fullNameTF: UITextField!
    
    @IBOutlet weak var sourceTF: UITextField!
    
    @IBOutlet weak var destinationTF: UITextField!
    
    @IBOutlet weak var noOfPassTF: UITextField!
    
    @IBOutlet weak var arrivalDateTF: UITextField!
    
    
    @IBOutlet weak var departureDateTF: UITextField!
    
}

