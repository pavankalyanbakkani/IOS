//
//  SellerProductDetailVC.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/07/2022.
//

import UIKit

class SellerProductDetailVC: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    @IBOutlet weak var locationtxt: UITextField!
    @IBOutlet weak var pricetxt: UITextField!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var updateButtonVw: UIView!
    @IBOutlet weak var descriptionTxt: UITextField!
    @IBOutlet weak var imageContainerVw: UIView!

    @IBOutlet weak var warrentyTxt: UITextField!
    @IBOutlet weak var imgVw: UIImageView!
    @IBOutlet weak var qtytxt: UITextField!
    @IBOutlet weak var editVw: UIView!
    @IBOutlet weak var nametxt: UITextField!
    @IBOutlet weak var selectImgButton: UIButton!
    @IBOutlet weak var typetxt: UITextField!
    
    var isEdit = false
    var isAdding = false
    var selectedProduct = Product()
    var dbHelper = DB_Helper()
    var types = [String]()
    var locations = ["California",
                     "New York",
                     "New Jersey",
                     "Texas",
                     "Florida",
                     "Missouri"]
    var warrantyPeriods = [1,2,3,4,5,6,7,8,9,10,11,12]
    var selectedWarranty = 0
    
    
    let typesPicker = UIPickerView()
    let locationPicker = UIPickerView()
    let warrantyPicker = UIPickerView()
    var picker = UIImagePickerController();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        types = Constants.ProductsList
        self.hideKeyboardWhenTappedAround()
        if isAdding == true
        {
            self.title = "Add Product"
        }
        else
        {
            self.title = "Product Details"
        }
        self.typesPicker.delegate = self
        self.locationPicker.delegate = self
        self.warrantyPicker.delegate = self
        self.warrentyTxt.delegate = self
        self.picker.delegate = self
        self.typetxt.delegate = self
        self.locationtxt.delegate = self
        self.typetxt.inputView = typesPicker
        self.locationtxt.inputView = locationPicker
        warrentyTxt.inputView = warrantyPicker
        self.setupVw()
    }
    func setupVw()
    {
        if isEdit == true
        {
            self.updateButton.setTitle("Update", for: .normal)
            self.updateButtonVw.isHidden = false
            self.editVw.isHidden = false
            self.descriptionTxt.isEnabled = true
            self.warrentyTxt.isEnabled = true
            self.selectImgButton.isEnabled = true
            self.imageContainerVw.isHidden = false
            self.qtytxt.isEnabled = true
            self.nametxt.isEnabled = true
            self.typetxt.isEnabled = true
            self.pricetxt.isEnabled = true
            self.locationtxt.isEnabled = true
            self.descriptionTxt.text = selectedProduct.desc ?? ""
            
            self.selectedWarranty = selectedProduct.warranty ?? 0
            self.imgVw.image = selectedProduct.image ?? UIImage()
            self.qtytxt.text = "\(selectedProduct.qty ?? 0)"
            self.nametxt.text = selectedProduct.name ?? ""
            self.typetxt.text = selectedProduct.type ?? ""
            self.pricetxt.text = "\(selectedProduct.price ?? 0)"
            self.locationtxt.text = selectedProduct.location ?? ""
            if selectedProduct.warranty ?? 0 <= 1
            {
                self.warrentyTxt.text = "\(selectedProduct.warranty ?? 0) months"
            }
            else
            {
                self.warrentyTxt.text = "\(selectedProduct.warranty ?? 0) months"
            }
        }
        else if isAdding == true
        {
            self.updateButtonVw.isHidden = true
            self.editVw.isHidden = true
            self.descriptionTxt.isEnabled = true
            self.warrentyTxt.isEnabled = true
            self.selectImgButton.isEnabled = true
            self.qtytxt.isEnabled = true
            self.nametxt.isEnabled = true
            self.typetxt.isEnabled = true
            self.pricetxt.isEnabled = true
            self.locationtxt.isEnabled = true
            self.updateButton.setTitle("Add", for: .normal)
            self.imageContainerVw.isHidden = true
            updateButtonVw.isHidden = false
        }
        else
        {
            updateButtonVw.isHidden = true
            self.editVw.isHidden = false
            self.descriptionTxt.text = selectedProduct.desc ?? ""
            
            self.selectedWarranty = selectedProduct.warranty ?? 0
            self.imgVw.image = selectedProduct.image ?? UIImage()
            self.qtytxt.text = "\(selectedProduct.qty ?? 0)"
            self.nametxt.text = selectedProduct.name ?? ""
            self.typetxt.text = selectedProduct.type ?? ""
            self.pricetxt.text = "\(selectedProduct.price ?? 0)"
            self.locationtxt.text = selectedProduct.location ?? ""
            self.imageContainerVw.isHidden = false
            self.descriptionTxt.isEnabled = true
            self.warrentyTxt.isEnabled = false
            self.selectImgButton.isEnabled = false
            self.imageContainerVw.isHidden = false
            self.qtytxt.isEnabled = false
            self.nametxt.isEnabled = false
            self.typetxt.isEnabled = false
            self.pricetxt.isEnabled = false
            self.locationtxt.isEnabled = false
            
            if selectedProduct.warranty ?? 0 <= 1
            {
                self.warrentyTxt.text = "\(selectedProduct.warranty ?? 0) month"
            }
            else
            {
                self.warrentyTxt.text = "\(selectedProduct.warranty ?? 0) months"
            }
        }
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == self.typetxt
        {
            if textField.text?.isEmpty == true
            {
                textField.text = self.types[0]
            }
        }
        else if textField == self.locationtxt
        {
            if textField.text?.isEmpty == true
            {
                textField.text = self.locations[0]
            }
        }
        else if textField == self.warrentyTxt
        {
            if textField.text?.isEmpty == true
            {
                textField.text = "\(self.warrantyPeriods[0]) month"
            }
        }
        
        return true
    }
    @IBAction func editbtn(_ sender: Any) {
        self.isEdit = true
        self.updateButtonVw.isHidden = false
        self.descriptionTxt.isEnabled = true
        self.warrentyTxt.isEnabled = true
        self.selectImgButton.isEnabled = true
        self.imageContainerVw.isHidden = false
        self.qtytxt.isEnabled = true
        self.nametxt.isEnabled = true
        self.typetxt.isEnabled = true
        self.pricetxt.isEnabled = true
        self.locationtxt.isEnabled = true
        self.nametxt.becomeFirstResponder()
    }
    @IBAction func updateBtn(_ sender: Any) {
        
        if nametxt.text?.isEmpty == false && typetxt.text?.isEmpty == false && qtytxt.text?.isEmpty == false && pricetxt.text?.isEmpty == false && locationtxt.text?.isEmpty == false && warrentyTxt.text?.isEmpty == false && imgVw.image != nil && descriptionTxt.text?.isEmpty == false
        {
            let pid = selectedProduct.id ?? 0
            let imgBase64 = Constants.convertImageToBase64String(img: self.imgVw.image ?? UIImage())
            let isUpdated = self.dbHelper.updateProduct(id: pid, name: self.nametxt.text ?? "" , price: Double(pricetxt.text ?? "0") ?? 0 , warrenty: self.selectedWarranty, type: self.typetxt.text ?? "", qty: Int(qtytxt.text ?? "0") ?? 0, desc: self.descriptionTxt.text ?? "", image:imgBase64 , location: self.locationtxt.text ?? "")
            if isUpdated == true
            {
                if isAdding == true
                {
                    self.navigationController?.popToRootViewController(animated: true)
                    
                    Constants.showAlert("", message: "Your product is added successfully.")
                }
                else if isEdit == true
                {
                    self.navigationController?.popToRootViewController(animated: true)
                    
                    Constants.showAlert("", message: "Your product is updated successfully.")
                }
            }
        }
        else
        {
            Constants.showAlert("", message: "Please fill all details of product to continue.")
        }
    }
    
    @IBAction func selectImgbtn(_ sender: Any) {
        self.showGalleryOpt()
    }
    func showGalleryOpt(){
        
        let alert = UIAlertController(title: "Upload Picture", message: "Please Select an Option", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { (_) in
            self.getPhotoFromLib()
        }))
        
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (_) in
            self.getPhotoFromCam()
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (_) in
            print("User click Delete button")
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func getPhotoFromLib(){
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.allowsEditing = true
        vc.delegate = self
        present(vc, animated: true, completion: nil)
    }
    
    func getPhotoFromCam(){
        let vc = UIImagePickerController()
        vc.sourceType = .camera
        vc.allowsEditing = true
        vc.delegate = self
        present(vc, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.editedImage] as? UIImage{
            selectImgButton.setTitle("Image is Selected...", for: .normal)
            self.imgVw.image = image
            self.imageContainerVw.isHidden = false
            picker.dismiss(animated: true, completion: nil)
        }
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == typesPicker
        {
            return types.count
        }
        else if pickerView == warrantyPicker
        {
            return warrantyPeriods.count
        }
        else
        {
            return locations.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == typesPicker
        {
            return types[row]
        }
        else if pickerView == warrantyPicker
        {
            if warrantyPeriods[row] == 1
            {
                return "\(warrantyPeriods[row]) month"
            }
            else
            {
                return "\(warrantyPeriods[row]) months"
            }
        }
        else
        {
            return locations[row]
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == typesPicker
        {
            typetxt.text = types[row]
        }
        else if pickerView == warrantyPicker
        {
            if warrantyPeriods[row] == 1
            {
                warrentyTxt.text = "\(warrantyPeriods[row]) month"
            }
            else
            {
                warrentyTxt.text = "\(warrantyPeriods[row]) months"
            }
            selectedWarranty = warrantyPeriods[row]
        }
        else
        {
            locationtxt.text = locations[row]
        }
    }
}
