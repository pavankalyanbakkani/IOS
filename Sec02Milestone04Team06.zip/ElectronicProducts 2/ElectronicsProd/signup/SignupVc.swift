//
//  SignupVc.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/06/2022.
//

import UIKit

class SignupVc: UIViewController,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource {
   
    

    @IBOutlet weak var emailtxt: UITextField!
    @IBOutlet weak var usernametxt: UITextField!
    @IBOutlet weak var addresstxt: UITextField!
    @IBOutlet weak var passtxt: UITextField!
    @IBOutlet weak var confirmPasstxt: UITextField!
    @IBOutlet weak var userTypetxt: UITextField!
    
    let pickerVw = UIPickerView()
    let userTypes = ["Seller","Buyer"]
    var dbHelper = DB_Helper()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "SIGN UP"
        self.userTypetxt.delegate = self
        self.pickerVw.delegate = self
        self.userTypetxt.inputView = pickerVw
        self.hideKeyboardWhenTappedAround()
    }
    @IBAction func signup(_ sender: Any) {
        if emailtxt.text?.isEmpty == true
        {
            Constants.showAlert("", message: "Please enter email.")
        }
        else if usernametxt.text?.isEmpty == true
        {
            Constants.showAlert("", message: "Please enter username.")
        }
        else if addresstxt.text?.isEmpty == true
        {
            Constants.showAlert("", message: "Please enter address.")
        }
        else if passtxt.text?.isEmpty == true
        {
            Constants.showAlert("", message: "Please enter password.")
        }
        else if confirmPasstxt.text?.isEmpty == true
        {
            Constants.showAlert("", message: "Please re-enter password.")
        }
        else if confirmPasstxt.text ?? "" != passtxt.text ?? ""
        {
            Constants.showAlert("", message: "Your password doesn't match.")
        }
        else if userTypetxt.text?.isEmpty == true
        {
            Constants.showAlert("", message: "Please select user type.")
        }
        else
        {
           let is_registered = self.dbHelper.saveUser(email: emailtxt.text?.lowercased() ?? "" , name: usernametxt.text ?? "", address: addresstxt.text ?? "", password: passtxt.text ?? "", userType: userTypetxt.text ?? "")
            if is_registered == true
            {
                self.navigationController?.popViewController(animated: true)
                Constants.showAlert("Registered", message: "User registered successfully.")
            }
        }
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == self.userTypetxt
        {
            if textField.text?.isEmpty == true
            {
                textField.text = userTypes[0]
            }
        }
        return true
    }
    @IBAction func signin(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return userTypes[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        userTypetxt.text = userTypes[row]
    }
    func pickerView(_ pickerView: UIPickerView,
         numberOfRowsInComponent component: Int) -> Int
    {
        return userTypes.count
    }
}
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    
    func showToast(message : String) {

        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 150, y: self.view.frame.size.height-100, width: 300, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.numberOfLines = 0
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 1.0, delay: 0.2, options: .curveLinear, animations: {
             toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }
    
}
