//
//  login.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/05/2022.
//

import UIKit

class login: UIViewController {

    @IBOutlet weak var passwordtxt: UITextField!
    @IBOutlet weak var emailtxt: UITextField!
    var dbHelper = DB_Helper()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "LOGIN"
        
        let isloggedIn = UserDefaults.standard.bool(forKey: "isLoggedIn")
        if isloggedIn == true
        {
            Constants.userid = UserDefaults.standard.value(forKey: "userid") as? Int ?? 0
            Constants.name = UserDefaults.standard.value(forKey: "name") as? String ?? ""
            Constants.email = UserDefaults.standard.value(forKey: "email") as? String ?? ""
            Constants.userType = UserDefaults.standard.value(forKey: "userType") as? String ?? ""
            Constants.address = UserDefaults.standard.value(forKey: "address") as? String ?? ""
            
            if Constants.userid != 0 && Constants.name.isEmpty == false && Constants.email.isEmpty == false && Constants.userType.isEmpty == false
            {
                if Constants.userType == "Seller"
                {
                    self.performSegue(withIdentifier: "sellerHome", sender: nil)
                }
                else
                {
                    self.performSegue(withIdentifier: "home", sender: nil)
                }
            }
        }
    }
    func getAlluser()
    {
        self.dbHelper.getAllUsers()?.forEach({ (obj) in
            let id = obj.value(forKey: "id") as? Int ?? 0
            let name = obj.value(forKey: "name") as? String ?? ""
            let email = obj.value(forKey: "email") as? String ?? ""
            let userType = obj.value(forKey: "userType") as? String ?? ""
            let pass = obj.value(forKey: "password") as? String ?? ""
            let address = obj.value(forKey: "address") as? String ?? ""

            print("userid \(id),\n name \(name),\n email \(email), \n userType \(userType), \n password \(pass), \n address \(address)")
        })
    }
    
    func getAllProducts()
    {
        self.dbHelper.getAllProducts()?.forEach({ (obj) in
            print("products id \(obj.value(forKey: "id")),name \(obj.value(forKey: "name")),price \(obj.value(forKey: "price")),userid \(obj.value(forKey: "userid")),image \(obj.value(forKey: "image"))")
        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        emailtxt.text = ""
        passwordtxt.text = ""
    }
    @IBAction func signinbtn(_ sender: Any) {
        if emailtxt.text?.isEmpty == true
        {
            Constants.showAlert("", message: "Please enter email")
            return
        }
        else if passwordtxt.text?.isEmpty == true
        {
            Constants.showAlert("", message: "Please enter password")
            return
        }
        else
        {
            self.login()
        }
    }
    func login()
    {
       if let user = self.dbHelper.userLogin(email: emailtxt.text ?? "", password: passwordtxt.text ?? "")
        {
           Constants.userid = user.value(forKey: "id") as? Int ?? 0
           Constants.name = user.value(forKey: "name") as? String ?? ""
           Constants.email = user.value(forKey: "email") as? String ?? ""
           Constants.userType = user.value(forKey: "userType") as? String ?? ""
           Constants.address = user.value(forKey: "address") as? String ?? ""
           
           var isLoggedIn = true
           UserDefaults.standard.set(isLoggedIn, forKey: "isLoggedIn")
           UserDefaults.standard.set(Constants.userid, forKey: "userid")
           UserDefaults.standard.set(Constants.name, forKey: "name")
           UserDefaults.standard.set(Constants.email, forKey: "email")
           UserDefaults.standard.set(Constants.userType, forKey: "userType")
           UserDefaults.standard.set(Constants.address, forKey: "address")
           
           if Constants.userType == "Seller"
           {
               self.performSegue(withIdentifier: "sellerHome", sender: nil)
           }
           else
           {
               self.performSegue(withIdentifier: "home", sender: nil)
           }
       }
        else
        {
            Constants.showAlert("", message: "Username or password is invalid")
        }
    }
    @IBAction func signup(_ sender: Any) {
        self.performSegue(withIdentifier: "signup", sender: nil)
    }
}
