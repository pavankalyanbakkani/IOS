//
//  MyOrdersCell.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/15/2022.
//

import UIKit

class MyOrdersCell: UITableViewCell {

    @IBOutlet weak var viewdetailButton: UIButton!
    @IBOutlet weak var qty: UILabel!
    @IBOutlet weak var totallbl: UILabel!
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var img: UIImageView!
    

    }


