//
//  headerView.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/17/2022.
//

import UIKit

class headerView: UITableViewHeaderFooterView {

    
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var totallbl: UILabel!
    @IBOutlet weak var orderDatelbl: UILabel!
    
}
