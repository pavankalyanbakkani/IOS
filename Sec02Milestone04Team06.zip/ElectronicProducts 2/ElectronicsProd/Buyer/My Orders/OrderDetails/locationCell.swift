//
//  locationCell.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/13/2022.
//

import UIKit

class locationCell: UITableViewCell {

    @IBOutlet weak var txtlbl: UILabel!
   
    }

   
