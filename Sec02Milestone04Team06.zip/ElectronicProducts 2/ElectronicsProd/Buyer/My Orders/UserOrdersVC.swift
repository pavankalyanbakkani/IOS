//
//  UserOrdersVC.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/15/2022.
//

import UIKit

class UserOrdersVC: UIViewController
{

    @IBOutlet weak var ordersTbl: UITableView!
       
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
     
}

