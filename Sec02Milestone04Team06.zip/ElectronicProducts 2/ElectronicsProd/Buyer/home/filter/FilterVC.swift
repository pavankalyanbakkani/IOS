//
//  FilterVC.swift
//  ElectronicsProd
//
//  Created by Bakkani,Pavan Kalyan on 11/07/2022.
//

import UIKit

class FilterVC: UIViewController 
{

    @IBOutlet weak var maxtxt: UITextField!
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var mintxt: UITextField!
    @IBOutlet weak var locationtbl: UITableView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
           }
    
}
