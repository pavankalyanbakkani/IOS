//
//  modelFile.swift
//  ElectronicsProd
//
//  Created by Student on 04/11/2022.
//

import Foundation
import UIKit

struct Product {
    var name : String?
    var qty : Int?
    var price : Double?
    var warranty : Int?
    var id : Int?
    var type : String?
    var location : String?
    var image : UIImage?
    var desc : String?
    var cartValue : Int?
    var sellerid : Int?
    var warrantyEnd : Date?
}


struct UserOrderModel {
    var orderDate : Date?
    var orderId : Int?
    var total:Double?
    var jsonData : [Cart]?
}


struct Cart : Codable{
    var name : String?
    var qty : Int?
    var price : Double?
    var warranty : Int?
    var id : Int?
    var type : String?
    var location : String?
    var image : String?
    var desc : String?
    var cartValue : Int?
    var maxQuantity : Int?
    var sellerid : Int?
    var buyerid : Int?
    var warrantyEnd : Date?
}

struct UserOrder : Codable {
    var name : String?
    var qty : Int?
    var price : Double?
    var warranty : Int?
    var id : Int?
    var type : String?
    var location : String?
    var image : String?
    var desc : String?
    var sellerid : Int?
    var buyerid : Int?
    var total : Double?
    var orderDate : Date?
    var warrantyEnd : Date?
    var orderid : Int?
}
