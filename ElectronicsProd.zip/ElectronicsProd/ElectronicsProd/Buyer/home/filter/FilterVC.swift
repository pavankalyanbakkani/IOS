//
//  FilterVC.swift
//  ElectronicsProd
//
//  Created by Student on 09/11/2022.
//

import UIKit

class FilterVC: UIViewController ,UITableViewDelegate,UITableViewDataSource{

    @IBOutlet weak var maxtxt: UITextField!
    @IBOutlet weak var tbl: UITableView!
    @IBOutlet weak var mintxt: UITextField!
    @IBOutlet weak var locationtbl: UITableView!
    var types = [String]()
    let locations = ["California",
                     "New York",
                     "New Jersey",
                     "Texas",
                     "Florida",
                     "Georgia"]
    var selectedTypes = [String]()
    var selectedLocations = [String]()
    var delegate : filterDelegates?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        types = Constants.ProductsList
        tbl.delegate = self
        tbl.dataSource = self
        locationtbl.delegate = self
        locationtbl.dataSource = self
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tbl
        {
           return types.count
        }
        else
        {
           return locations.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == tbl
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = types[indexPath.row]
            let item = selectedTypes.first {$0 == types[indexPath.row]}
            if item != nil
            {
                cell.accessoryType = .checkmark
            }
            else
            {
                cell.accessoryType = .none
            }
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = locations[indexPath.row]
            let item = selectedLocations.first {$0 == locations[indexPath.row]}
            if item != nil
            {
                cell.accessoryType = .checkmark
            }
            else
            {
                cell.accessoryType = .none
            }
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == tbl
        {
            addType(name: types[indexPath.row])
            tbl.reloadData()
        }
        else
        {
            addLocation(name: locations[indexPath.row])
            locationtbl.reloadData()
        }
    }
    func addType(name: String) {
        let index = selectedTypes.firstIndex { $0 == name}
        if (index == nil) {
            selectedTypes.append(name)
        }
        else {
            removeType(name: name)
        }
    }
    
    func removeType(name: String) {
        let index = selectedTypes.firstIndex { $0 == name}
        if (index != nil) {
            selectedTypes.remove(at: index!)
        }
    }
    
    func addLocation(name: String) {
        let index = selectedLocations.firstIndex { $0 == name}
        if (index == nil) {
            selectedLocations.append(name)
        }
        else {
            removeLocation(name: name)
        }
    }
    
    func removeLocation(name: String) {
        let index = selectedLocations.firstIndex { $0 == name}
        if (index != nil) {
            selectedLocations.remove(at: index!)
        }
    }
    
    
    @IBAction func applybtn(_ sender: Any) {
        
        let min = Int(mintxt.text ?? "0") ?? 0
        let max = Int(maxtxt.text ?? "0") ?? 0
        
        if selectedLocations.isEmpty == true
        {
            selectedLocations = locations
        }
        if selectedTypes.isEmpty == true
        {
            selectedTypes = types
        }
        
        if min != 0 && max != 0
        {
            if min > max
            {
                Constants.showAlert("", message: "Miximum amount must be greater than minimum amount.")
                return
            }
            else
            {
                self.delegate?.getFilterValue(isApplied: true, types: selectedTypes, min: min, max: max, locations: selectedLocations)
                self.dismiss(animated: true)
            }
        }
        else
        {
            self.delegate?.getFilterValue(isApplied: true, types: selectedTypes, min: min, max: max, locations: selectedLocations)
            self.dismiss(animated: true)
    }
}
    @IBAction func cancelbtn(_ sender: Any) {
        self.delegate?.getFilterValue(isApplied: false, types: [], min: 0, max: 0, locations: [])
        self.dismiss(animated: true)
    }
}

protocol filterDelegates {
    func getFilterValue(isApplied : Bool,types : [String],min:Int,max:Int,locations:[String])
}
