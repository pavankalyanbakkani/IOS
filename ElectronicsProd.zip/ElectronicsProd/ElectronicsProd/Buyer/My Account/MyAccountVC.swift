//
//  MyAccountVC.swift
//  ElectronicsProd
//
//  Created by Student on 08/11/2022.
//

import UIKit

class MyAccountVC: UIViewController {

    @IBOutlet weak var addresslbl: UILabel!
    @IBOutlet weak var emailtxt: UILabel!
    @IBOutlet weak var usernamelbl: UILabel!
    @IBOutlet weak var usertypelbl: UILabel!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Profile"
        self.setupVw()
    }

    func setupVw()
    {
        
        self.usernamelbl.text = Constants.name
        self.addresslbl.text = Constants.address
        self.emailtxt.text = Constants.email
        self.usertypelbl.text = Constants.userType
    }
    @IBAction func logoutbtn(_ sender: Any) {
        self.alert()
    }
    func alert()
    {
        let refreshAlert = UIAlertController(title: "Logout", message: "Are you sure you want to logoout?", preferredStyle: UIAlertController.Style.alert)

        refreshAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action: UIAlertAction!) in
              print("Handle Cancel Logic here")
        }))
        refreshAlert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action: UIAlertAction!) in
              print("Handle Ok logic here")
            
            UserDefaults.standard.set(false, forKey: "isLoggedIn")
            UserDefaults.standard.set(0, forKey: "userid")
            UserDefaults.standard.set("", forKey: "name")
            UserDefaults.standard.set("", forKey: "email")
            UserDefaults.standard.set("", forKey: "userType")
            
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyboard.instantiateViewController(withIdentifier: "RootNavigationController") as! UINavigationController
            UIApplication.shared.keyWindow?.rootViewController = viewController;
            return
        }))

        present(refreshAlert, animated: true, completion: nil)
    }
}
