//
//  ComplainVC.swift
//  ElectronicsProd
//
//  Created by Student on 08/11/2022.
//

import UIKit

class ComplainVC: UIViewController,UITextViewDelegate {
    
    @IBOutlet weak var detailstxt: UITextView!
    var selectedOrder = Cart()
    var dbhelper = DB_Helper()
    var placeholder = "Enter Complain Details"
    var orderid = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Claim Product" 
        detailstxt.delegate = self
        detailstxt.text = placeholder
        detailstxt.textColor = UIColor.lightGray
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = placeholder
            textView.textColor = UIColor.lightGray
        }
    }
    @IBAction func submitbtn(_ sender: Any) {
        if selectedOrder.warrantyEnd ?? Date() < Date()
        {
            Constants.showAlert("", message: "Warranty is over.You cannot claim this product now.")
        }
        else
        {
            if detailstxt.text == placeholder
            {
                Constants.showAlert("", message: "Please enter claim details to continue.")
                return
            }
            else
            {
                self.claimPro()
            }
        }
    }
    func claimPro()
    {
        let isAdded = self.dbhelper.addToComplain(complainDetails: detailstxt.text, buyerid: selectedOrder.buyerid ?? 0, productId: self.selectedOrder.id ?? 0, productName: self.selectedOrder.name ?? "", productPrice: self.selectedOrder.price ?? 0, productType: self.selectedOrder.type ?? "", productWarranty: self.selectedOrder.warranty ?? 0, sellerid: self.selectedOrder.sellerid ?? 0, orderId: self.orderid)
        if isAdded == true
        {
            self.showToast(message: "Product claimed.")
            self.navigationController?.popToRootViewController(animated: true)
        }
    } 
}
