//
//  MyOrdersCell.swift
//  ElectronicsProd
//
//  Created by Student on 07/11/2022.
//

import UIKit

class MyOrdersCell: UITableViewCell {

    @IBOutlet weak var viewdetailButton: UIButton!
    @IBOutlet weak var qty: UILabel!
    @IBOutlet weak var totallbl: UILabel!
    @IBOutlet weak var namelbl: UILabel!
    @IBOutlet weak var img: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
