//
//  headerView.swift
//  ElectronicsProd
//
//  Created by Student on 18/11/2022.
//

import UIKit

class headerView: UITableViewHeaderFooterView {

    
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var totallbl: UILabel!
    @IBOutlet weak var orderDatelbl: UILabel!
    
}
