//
//  UserOrdersVC.swift
//  ElectronicsProd
//
//  Created by Student on 06/11/2022.
//

import UIKit

class UserOrdersVC: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var ordersTbl: UITableView!
    var orders = [UserOrderModel]()
    var dbHelper = DB_Helper()
    var selectedOrder = Cart()
    var selectedIndexPath : IndexPath?
    var orderid = 0
    var orderDate = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "My Orders"
        self.ordersTbl.delegate = self
        self.ordersTbl.dataSource = self
        let headerNib = UINib.init(nibName: "headerView", bundle: Bundle.main)
        ordersTbl.register(headerNib, forHeaderFooterViewReuseIdentifier: "headerView")
    }
    override func viewWillAppear(_ animated: Bool) {
        self.getAllOrders()
    }
    func getAllOrders()
    {
        orders.removeAll()
        self.ordersTbl.reloadData()
        self.dbHelper.getUserAllOrdersByUserid(buyerid: Constants.userid)?.forEach({(obj)in
            
            let orderid = obj.value(forKey: "id") as? Int ?? 0
            let total = obj.value(forKey: "total") as? Double ?? 0
            let orderDate = obj.value(forKey: "orderDate") as? Date ?? Date()
            let json = obj.value(forKey: "jsonData") as? String ?? ""
            
            let data = json.data(using: .utf8)!
            let model = try? JSONDecoder().decode([Cart].self, from: data)
            
            self.orders.append(UserOrderModel.init(orderDate:orderDate, orderId: orderid, total: total, jsonData: model))
            
//            let name = obj.value(forKey: "name") as? String ?? ""
//            let qty = obj.value(forKey: "quantity") as? Int ?? 0
//            let price = obj.value(forKey: "price") as? Double ?? 0
//            let warrenty = obj.value(forKey: "warranty") as? Int ?? 0
//            let id = obj.value(forKey: "productId") as? Int ?? 0
//            let type = obj.value(forKey: "type") as? String ?? ""
//            let location = obj.value(forKey: "location") as? String ?? ""
//            let buyerid = obj.value(forKey: "buyerid") as? Int ?? 0
//            let sellerid = obj.value(forKey: "sellerid") as? Int ?? 0
//            let total = obj.value(forKey: "total") as? Double ?? 0
//            let orderDate = obj.value(forKey: "orderDate") as? Date ?? Date()
//            let orderId = obj.value(forKey: "ordrId") as? Int ?? 0
//            let warrantyEnd = obj.value(forKey: "warrantyEndDate") as? Date ?? Date()
//            let image = Constants.convertBase64StringToImage(imageBase64String: obj.value(forKey: "image") as? String ?? "")
//            let desc = obj.value(forKey: "desc") as? String ?? ""
//            self.orders.append(UserOrder(name: name, qty: qty, price: price, warranty: warrenty, id: id, type: type, location: location, image: image, desc: desc,sellerid: sellerid, buyerid: buyerid,total: total,orderDate: orderDate,warrantyEnd: warrantyEnd, orderid: orderId))
        })
        self.ordersTbl.reloadData()
        if orders.isEmpty == true
        {
            Constants.showAlert("", message: "No Products added yet.")
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return orders.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return orders[section].jsonData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyOrdersCell", for: indexPath) as! MyOrdersCell
        cell.img.image = Constants.convertBase64StringToImage(imageBase64String: orders[indexPath.section].jsonData?[indexPath.row].image ?? "")
        cell.namelbl.text = orders[indexPath.section].jsonData?[indexPath.row].name ?? ""
        cell.totallbl.text = "\(orders[indexPath.section].jsonData?[indexPath.row].price ?? 0.0)"
        cell.qty.text = "\(orders[indexPath.section].jsonData?[indexPath.row].cartValue ?? 0)"
        cell.viewdetailButton.isEnabled = false
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedOrder = self.orders[indexPath.section].jsonData?[indexPath.row] ?? Cart()
        self.orderid = self.orders[indexPath.section].orderId ?? 0
        self.orderDate = self.orders[indexPath.section].orderDate ?? Date()
        self.performSegue(withIdentifier: "detail", sender: nil)
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "headerView") as? headerView
        headerView?.orderDatelbl.text = "\(Constants.FormattedDate(date: orders[section].orderDate ?? Date()))"
        headerView?.totallbl.text = "\(orders[section].total ?? 0)"
        headerView?.deleteButton.tag = section
        headerView?.deleteButton.addTarget(self, action: #selector(deleteClicked(sender:)), for: .touchUpInside)
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 150
    }
    @objc func deleteClicked(sender:UIButton){
        
        if let orderid = self.orders[sender.tag].orderId
        {
            self.alert(orderid: orderid)
        }
    }
    
    func alert(orderid:Int)
    {
        let refreshAlert = UIAlertController(title: "Confirmation", message: "Are you sure you want to delete this order?", preferredStyle: UIAlertController.Style.alert)

        refreshAlert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action: UIAlertAction!) in
              print("Handle Cancel Logic here")
        }))
        refreshAlert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action: UIAlertAction!) in
              print("Handle Ok logic here")
            self.deletOrderByid(orderid: orderid)
            return
        }))

        present(refreshAlert, animated: true, completion: nil)
    }
    
    func deletOrderByid(orderid:Int)
    {
        self.dbHelper.deleteOrderbyid(orderid: orderid, buyerid: Constants.userid)
        self.getAllOrders()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detail"
        {
            let vc = segue.destination as! OrderDetailsVC
            vc.selectedOrder = self.selectedOrder
            vc.isClaim = true
            vc.orderid = self.orderid
            vc.orderDate = self.orderDate
        }
    }
}
