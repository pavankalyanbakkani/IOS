//
//  PaymentVC.swift
//  ElectronicsProd
//
//  Created by Student on 06/11/2022.
//

import UIKit


class PaymentVC: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate {
    
    
    @IBOutlet weak var ziptx: UITextField!
    @IBOutlet weak var apptTxt: UITextField!
    @IBOutlet weak var citytxt: UITextField!
    @IBOutlet weak var stateTxt: UITextField!
    @IBOutlet weak var addresstxt: UITextField!
    @IBOutlet weak var subtotallbl: UILabel!
    @IBOutlet weak var taxlbl: UILabel!
    @IBOutlet weak var cardNumbertxt: UITextField!
    @IBOutlet weak var totallbl: UILabel!
    @IBOutlet weak var yearTxt: UITextField!
    @IBOutlet weak var monthtxt: UITextField!
    var months = [01,02,03,04,05,06,07,08,09,10,11,12]
    let monthPicker = UIPickerView()
    let totalQuantity = 0
    var total = 0.0
    var cartList = [Cart]()
    var dbHelper = DB_Helper()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        monthPicker.delegate = self
        monthtxt.inputView = monthPicker
        yearTxt.delegate = self
        self.monthtxt.delegate = self
        cardNumbertxt.delegate = self
        
        for item in cartList
        {
            total += ((item.price ?? 0.0) * Double((item.cartValue ?? 0)))
        }
        self.subtotallbl.text = "\(total)"
        taxlbl.text = "10"
        self.totallbl.text = "\(total + 10)"
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == self.monthtxt
        {
            if textField.text?.isEmpty == true
            {
                textField.text = "\(months[0])"
            }
        }
        return true
    }
    @IBAction func buytxt(_ sender: Any) {
        if ziptx.text?.isEmpty == false && citytxt.text?.isEmpty == false && stateTxt.text?.isEmpty == false && addresstxt.text?.isEmpty == false && cardNumbertxt.text?.isEmpty == false && yearTxt.text?.isEmpty == false && monthtxt.text?.isEmpty == false
        {
            for item in cartList
            {
                let remainingQty = ((item.maxQuantity ?? 0) - (item.cartValue ?? 0))
                let isupdated = self.dbHelper.updateProductByBuyer(sellerid: item.sellerid ?? 0, id: item.id ?? 0, name: item.name ?? "", price: item.price ?? 0, warrenty: item.warranty ?? 0, type: item.type ?? "", qty: remainingQty, desc: item.desc ?? "", image: item.image ?? "", location: item.location ?? "")
//                if isupdated == true
//                {
//
//
//
//
//                    let isadded = self.dbHelper.userOrder(sellerid: item.sellerid ?? 0,buyerid: item.buyerid ?? 0,id: item.id ?? 0, name: item.name ?? "", price: item.price ?? 0.0, warrenty: item.warranty ?? 0, type: item.type ?? "", qty: item.cartValue ?? 0, desc: item.desc ?? "", image:item.image ?? "", location: item.location ?? "", total: self.total, warrantyEndDate: item.warrantyEnd ?? Date())
//
//                    if isadded == true
//                    {
//                        self.showToast(message: "Order processed successfully.")
//                    }
//                    else
//                    {
//                        self.showToast(message: "Order couln't be processed.")
//                    }
//                }
//                else
//                {
//                    Constants.showAlert("", message: "Your order cannot process.Please try again later.")
//                    return
//                }
  
            }
            
            let jsonData = try? JSONEncoder().encode(cartList)
            let json = String(data: jsonData!, encoding: String.Encoding.utf8)
            let isadded = self.dbHelper.userOrderNew(buyerid: Constants.userid, total: self.total, jsonData: json ?? "")
            if isadded == true
            {
                self.dbHelper.deleteAllcart()
                self.showToast(message: "Your order has been done successfully.")
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    
                    self.navigationController?.popViewController(animated: true)
                    self.tabBarController?.selectedIndex = 0
                }
            }
        }
        else if cardNumbertxt.text?.count ?? 0 < 19 && cardNumbertxt.text?.count ?? 0 < 0
        {
            Constants.showAlert("", message: "Please enter valid card number.")
        }
        else
        {
            Constants.showAlert("", message: "Please enter all required fields.")
        }
    }
    
    @IBAction func cancelbtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == yearTxt
        {
            let maxLength = 2
            let currentString = (textField.text ?? "") as NSString
            let newString = currentString.replacingCharacters(in: range, with: string)
            return newString.count <= maxLength
        }
        else if textField == cardNumbertxt {
            return formatCardNumber(textField: textField, shouldChangeCharactersInRange: range, replacementString: string)
        }
        return true
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return months.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return "\( months[row])"
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        monthtxt.text = "\(months[row])"
    }
    func formatCardNumber(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        if textField == cardNumbertxt {
            let replacementStringIsLegal = string.rangeOfCharacter(from: NSCharacterSet(charactersIn: "0123456789").inverted) == nil
            
            if !replacementStringIsLegal {
                return false
            }
            
            let newString = (textField.text! as NSString).replacingCharacters(in: range, with: string)
            let components = newString.components(separatedBy: NSCharacterSet(charactersIn: "0123456789").inverted)
            let decimalString = components.joined(separator: "") as NSString
            let length = decimalString.length
            let hasLeadingOne = length > 0 && decimalString.character(at: 0) == (1 as unichar)
            
            if length == 0 || (length > 16 && !hasLeadingOne) || length > 19 {
                let newLength = (textField.text! as NSString).length + (string as NSString).length - range.length as Int
                
                return (newLength > 16) ? false : true
            }
            var index = 0 as Int
            let formattedString = NSMutableString()
            
            if hasLeadingOne {
                formattedString.append("1 ")
                index += 1
            }
            if length - index > 4 {
                let prefix = decimalString.substring(with: NSRange(location: index, length: 4))
                formattedString.appendFormat("%@ ", prefix)
                index += 4
            }
            
            if length - index > 4 {
                let prefix = decimalString.substring(with: NSRange(location: index, length: 4))
                formattedString.appendFormat("%@ ", prefix)
                index += 4
            }
            if length - index > 4 {
                let prefix = decimalString.substring(with: NSRange(location: index, length: 4))
                formattedString.appendFormat("%@ ", prefix)
                index += 4
            }
            
            let remainder = decimalString.substring(from: index)
            formattedString.append(remainder)
            textField.text = formattedString as String
            return false
        } else {
            return true
        }
    }
}
