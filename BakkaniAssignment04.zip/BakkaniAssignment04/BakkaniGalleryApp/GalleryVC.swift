//
//  ViewController.swift
//  LastnameGalleryApp
//
//  Created by Bakkani,Pavan Kalyan on 10/11/22.
//

import UIKit

class GalleryVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.searchBTN.isEnabled = false

    }
    
    
    
    let rand: UInt32 = 100
    lazy var actor = [
        "keywords" : ["actor", "movie", "theatre", "film", "artist"],
        "pictures" : ["aish", "johnny", "Brosnan", "Puneeth_Rajkumar", "shahrukhkhan"],
        "descriptions": ["Aishwarya Rai Bachchan is an Indian actress and the winner of the Miss World 1994 pageant. Primarily known for her work in Hindi and Tamil films, she has es-tablished herself as one of the most popular and influential celebrities in India.", "John Christopher Depp II is an American actor and musician. He is the recipient of multiple acco-lades, including a Golden Globe Award and a Screen Actors Guild Award, in addition to nomina-tions for three Academy Awards and two BAFTA awards.", "Pierce Brendan Brosnan is an Irish actor and film producer. He is best known as the fifth actor to play secret agent James Bond in the Bond film series, starring in four films from 1995 to 2002.", "Puneeth Rajkumar, col-loquially known as Appu, was an Indian actor, playback singer, television presenter, and pro-ducer, who worked in Kannada cinema. He had been called, by the media and fans, \"Power Star\".", "Shah Rukh Khan, also known by the initialism SRK, is an Indian actor, film produc-er, and television personality who works in Hindi films. Referred to in the media as the \"Baadshah of Bollywood\" (in reference to his 1999 film Baadshah), \"King of Bollywood\" and \"King Khan\", he has appeared in more than 80 films, and earned numerous accolades, in-cluding 14 Filmfare Awards."],
        "likes" : [String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)),String(arc4random_uniform(rand)),String(arc4random_uniform(rand))],
        "dislikes" : [String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand))]
    ]
    
    lazy var bird = [
        "keywords" : ["bird", "raptor", "fowl", "warbler", "chick"],
        "pictures" : ["bird", "raptor", "fowl", "wrabler", "chick"],
        "descriptions": ["Birds are a group of warm-blooded vertebrates constituting the class Aves, characterised by feathers, toothless beaked jaws, the laying of hard-shelled eggs, a high metabolic rate, a four-chambered heart, and a strong yet lightweight skeleton.", "Birds of prey or predatory birds, also known as raptors, are hypercarnivorous bird species that actively hunt and feed on other vertebrates (mainly mammals, reptiles and other smaller birds). In addition to speed and strength, these predators have keen eyesight for detecting prey from a distance or during flight, strong feet with sharp talons for grasping or killing prey, and powerful, curved beaks for tearing off flesh.", "Fowl are birds belonging to one of two biological orders, namely the gamefowl or landfowl (Galliformes) and the waterfowl (An-seriformes). Anatomical and molecular similarities suggest these two groups are close evolu-tionary relatives; together, they form the fowl clade which is scientifically known as Gal-loanserae", "Various Passeriformes (perching birds) are commonly referred to as warblers. They are not necessarily closely related to one another, but share some characteristics, such as being fairly small, vocal, and insectivorous.", "Chick means any baby bird of any species from the moment it hatches until it leaves the nest"],
        "likes" : [String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand))],
        "dislikes" : [String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand))]
    ]
    
    
    lazy var cricketers = [
        "keywords" : ["Player","batsman", "bowler", "fast bowler", "best batsman"],
        "pictures" : ["ABD", "yusuf", "Mcgrath", "brettlee", "virat"],
        "descriptions": ["Abraham Benjamin de Villiers is a former South African international cricketer. AB de Villiers was named as the ICC ODI Player of the Year three times during his 15-year international career and was one of the five Wisden cricketers of the decade at the end of 2019", "Yusuf Pathan is an Indian former cricketer. Pathan made his debut in first-class cricket in 2001/02. He was a right-handed batsman and a right-arm offbreak bowler. His younger brother, Irfan Pathan was also an Indian cricketer. Pathan retired from all forms of cricket in February 2021.", "Glenn Donald McGrath AM (/məˈɡrɑː/; born 9 February 1970) is an Australian former international cricketer who played international cricket for 14 years. He was a fast-medium pace bowler and is considered one of the greatest international bowlers of all time,[1] and a leading contributor to Australia's domination of world cricket from the mid-1990s to the late-2000s", "Brett Lee is an Australian former international cricketer, who played all three formats of the game. During his international career, Lee was recognised as one of the fastest bowlers in the world", "Virat Kohli is an Indian international cricketer and former captain of the India national cricket team. He plays for Delhi in domestic cricket and Royal Challengers Bangalore in the Indian Premier League as a right-handed batsman. He is often considered as one of the greatest batsmen of all time"],
        "likes" : [String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand))],
        "dislikes" : [String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand)), String(arc4random_uniform(rand))]
    ]
    
    
    
    
    lazy var Albums = [actor, bird, cricketers]
    var searchIndex=0
    
    
    @IBAction func reset(_ sender: UIButton)
    {
        self.pictureDescTV.text = ""
        self.previousBTN.isEnabled = false
        self.nextBTN.isEnabled = false
        self.resetBTN.isEnabled = false
        self.searchBTN.isEnabled = false
        self.searchTF.text = ""
        self.likeBTN.setTitle("👍", for: .normal)
        self.dislikeBTN.setTitle("👎", for: .normal)
        pictureIV.image = UIImage(named: "")
        
        searchIndex = 0
    }
    
    
    @IBOutlet weak var resetBTN: UIButton!
    
    
    
    @IBOutlet weak var searchTF: UITextField!
    
    
    @IBAction func searchTF(_ sender: UITextField)
    {
        if searchTF.text==""
        {
            self.searchBTN.isEnabled  = false
        }
        else
        {
            self.searchBTN.isEnabled = true
        }
    }
    
    
    
    
    @IBOutlet weak var pictureIV: UIImageView!
    
    
    
    @IBOutlet weak var pictureDescTV: UITextView!
    
    
    @IBAction func search(_ sender: UIButton)
    {
        
        LatestSearch(index:searchIndex)
    }
    
    
    @IBOutlet weak var searchBTN: UIButton!
    
    
    @IBOutlet weak var likeBTN: UIButton!
    
    
    
    
    @IBAction func like(_ sender: UIButton) {
        
        var  p:Int = 0
        while ( p < Albums.count)
        {
            
            
            if let searchVal = Albums[p]["keywords"] , let likes = Albums[p]["likes"]
            {
                if searchVal.contains(searchTF.text!)
                {
                    if let num = Int(likes[searchIndex])
                    {
                        Albums[p]["likes"]?[searchIndex] = String(num + 1)
                        if let number = Albums[p]["likes"]?[searchIndex]
                        {
                            likeBTN.setTitle("👍 \(number)", for: .normal)
                        }
                    }
                    
                }
            }
            
            
            p = p+1
        }
    }
    
    @IBOutlet weak var dislikeBTN: UIButton!
    
    
    
    @IBAction func dislike(_ sender: UIButton)
    {
        var  c:Int = 0
        while ( c < Albums.count)
        {
            
            
            if let searchVal = Albums[c]["keywords"] , let dislikes = Albums[c]["dislikes"]
            {
                            if searchVal.contains(searchTF.text!)
                        {
                             if let num = Int(dislikes[searchIndex])
                            {
                             Albums[c]["dislikes"]?[searchIndex] = String(num + 1)
                             if let number = Albums[c]["dislikes"]?[searchIndex]
                                 {
                                   dislikeBTN.setTitle("👎 \(number)", for: .normal)
                                 }
                              }
            
                            }
          }
            
            
            c = c+1
            
        }
        
    }
    
    
    
    
    
    @IBOutlet weak var nextBTN: UIButton!
    
    
    func count() -> Int {
        var CountN = 0
        for i in Albums {
            
            if let searchVal2 = i["keywords"] , let DiplayPictures = i["pictures"]{
                if searchVal2.contains(searchTF.text!)
                {
                    CountN = DiplayPictures.count
                }
            }
            
        }
        return CountN
    }
    
    
    
    func getLikes() -> Int{
        let like: Int=0
        return like
    }
    
    
    
    @IBAction func next(_ sender: UIButton)
    {
        let p = count()
        if self.searchIndex < p-1
    {
        self.searchIndex += 1
        self.LatestSearch(index: self.searchIndex)
            
    }
        
    }
    
    
    
    
    @IBOutlet weak var previousBTN: UIButton!
    
    @IBAction func previous(_ sender: UIButton)
    {
        if self.searchIndex > 0
    {
            
        self.searchIndex -= 1
        self.LatestSearch(index: self.searchIndex)
            
            
    }
        
        
        
    }
    
        
        
    func LatestSearch(index: Int) {
        
        
        for  i in Albums
        {
            if let search = i["keywords"], let photos = i["pictures"], let likes = i["likes"], let dislikes = i["dislikes"] , let des = i["descriptions"]
               
               {
                if search.contains(searchTF.text!)
                {
                     pictureIV.image = UIImage(named: photos[index])
                     likeBTN.setTitle(" 👍\(likes[index])", for: .normal)
                    
                     dislikeBTN.setTitle("👎\(dislikes[index])", for: .normal)
                    
                     pictureDescTV.text = des[index]
                    
                    if index == 0
                    {
                         self.previousBTN.isEnabled = false
                         self.resetBTN.isEnabled = true
                        
                    }
                    else
                    {
                         self.previousBTN.isEnabled = true
                         self.resetBTN.isEnabled = true
                    }
                    
                    if index == photos.count-1
                    {
                         self.nextBTN.isEnabled = false
                         self.resetBTN.isEnabled = true
                         print("disable")
                    }
                    else
                    {
                         self.nextBTN.isEnabled = true
                         self.resetBTN.isEnabled = true
                    }
                    
                    return
                }
                else
                {
                      self.pictureDescTV.text = "Pardon me. please try again."
                      self.previousBTN.isEnabled = false
                      self.nextBTN.isEnabled = false
                      self.resetBTN.isEnabled = true
                }
            }
            
        }
        
        
    }
    
    
}





                    
